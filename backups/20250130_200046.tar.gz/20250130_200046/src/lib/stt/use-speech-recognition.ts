import { useState, useCallback, useRef, useEffect } from 'react';
import { useMutation } from '@tanstack/react-query';
import { WhisperClient } from './whisper-client';
import {
  TranscriptionOptions,
  TranscriptionState,
  WhisperSegment,
} from './whisper-types';

interface UseSpeechRecognitionOptions extends TranscriptionOptions {
  apiKey: string;
  maxDuration?: number;
  silenceThreshold?: number;
  onStart?: () => void;
  onStop?: () => void;
  onPause?: () => void;
  onResume?: () => void;
}

export function useSpeechRecognition({
  apiKey,
  maxDuration = 300, // 5 minutes
  silenceThreshold = 1.5, // 1.5 seconds
  model = 'whisper-1',
  language,
  prompt,
  temperature = 0,
  realtime = false,
  onSegment,
  onError,
  onStart,
  onStop,
  onPause,
  onResume,
}: UseSpeechRecognitionOptions) {
  const [state, setState] = useState<TranscriptionState>({
    isRecording: false,
    isPaused: false,
    isProcessing: false,
    error: null,
    text: '',
    segments: [],
    duration: 0,
    language: undefined,
  });

  // Refs
  const mediaRecorder = useRef<MediaRecorder | undefined>(undefined);
  const audioChunks = useRef<Blob[]>([]);
  const startTime = useRef<number>(0);
  const silenceStart = useRef<number>(0);
  const durationInterval = useRef<number | undefined>(undefined);
  const client = useRef<WhisperClient | undefined>(undefined);

  // Initialize client
  if (!client.current) {
    client.current = new WhisperClient(apiKey);
  }

  // Transcription mutation
  const { mutate: transcribe } = useMutation({
    mutationFn: async (audio: Blob) => {
      setState(prev => ({ ...prev, isProcessing: true }));
      try {
        const response = await client.current!.transcribe(audio, {
          model,
          language,
          prompt,
          temperature,
        });

        setState(prev => ({
          ...prev,
          isProcessing: false,
          text: response.text,
          segments: response.segments || [],
          language: response.language,
        }));

        if (response.segments) {
          response.segments.forEach(segment => {
            onSegment?.(segment);
          });
        }

        return response;
      } catch (error) {
        setState(prev => ({ ...prev, isProcessing: false, error: error as Error }));
        onError?.(error as Error);
        throw error;
      }
    },
  });

  // Start recording
  const startRecording = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorder.current = new MediaRecorder(stream);
      audioChunks.current = [];
      startTime.current = Date.now();

      // Set up event handlers
      mediaRecorder.current.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunks.current.push(event.data);

          // If realtime mode is enabled, transcribe each chunk
          if (realtime && audioChunks.current.length > 0) {
            const audio = new Blob(audioChunks.current, { type: 'audio/webm' });
            transcribe(audio);
            audioChunks.current = [];
          }
        }
      };

      // Start recording
      mediaRecorder.current.start(1000); // Collect data every second
      setState(prev => ({ ...prev, isRecording: true, isPaused: false }));
      onStart?.();

      // Start duration tracking
      durationInterval.current = window.setInterval(() => {
        const duration = (Date.now() - startTime.current) / 1000;
        setState(prev => ({ ...prev, duration }));

        // Stop if max duration is reached
        if (duration >= maxDuration) {
          stopRecording();
        }
      }, 100);

    } catch (error) {
      setState(prev => ({ ...prev, error: error as Error }));
      onError?.(error as Error);
    }
  }, [maxDuration, onError, onStart, realtime, transcribe]);

  // Stop recording
  const stopRecording = useCallback(() => {
    if (!mediaRecorder.current || mediaRecorder.current.state === 'inactive') return;

    return new Promise<void>((resolve) => {
      if (mediaRecorder.current) {
        mediaRecorder.current.onstop = async () => {
          // Stop all tracks
          mediaRecorder.current?.stream.getTracks().forEach(track => track.stop());

          // Clear interval
          if (durationInterval.current) {
            clearInterval(durationInterval.current);
          }

          // Process audio
          if (audioChunks.current.length > 0) {
            const audio = new Blob(audioChunks.current, { type: 'audio/webm' });
            transcribe(audio);
          }

          setState(prev => ({ 
            ...prev, 
            isRecording: false, 
            isPaused: false,
            duration: (Date.now() - startTime.current) / 1000,
          }));

          onStop?.();
          resolve();
        };

        mediaRecorder.current.stop();
      }
    });
  }, [onStop, transcribe]);

  // Pause recording
  const pauseRecording = useCallback(() => {
    if (!mediaRecorder.current || mediaRecorder.current.state !== 'recording') return;

    mediaRecorder.current.pause();
    setState(prev => ({ ...prev, isPaused: true }));
    onPause?.();
  }, [onPause]);

  // Resume recording
  const resumeRecording = useCallback(() => {
    if (!mediaRecorder.current || mediaRecorder.current.state !== 'paused') return;

    mediaRecorder.current.resume();
    setState(prev => ({ ...prev, isPaused: false }));
    onResume?.();
  }, [onResume]);

  // Clear transcription
  const clear = useCallback(() => {
    setState(prev => ({
      ...prev,
      text: '',
      segments: [],
      duration: 0,
      error: null,
    }));
  }, []);

  // Cleanup
  useEffect(() => {
    return () => {
      if (mediaRecorder.current) {
        mediaRecorder.current.stream.getTracks().forEach(track => track.stop());
      }
      if (durationInterval.current) {
        clearInterval(durationInterval.current);
      }
    };
  }, []);

  return {
    ...state,
    startRecording,
    stopRecording,
    pauseRecording,
    resumeRecording,
    clear,
  };
} 