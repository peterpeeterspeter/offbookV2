import {
  WhisperConfig,
  WhisperResponse,
  WhisperSegment,
  DEFAULT_WHISPER_CONFIG,
} from './whisper-types';

export class WhisperClient {
  private apiKey: string;
  private baseUrl: string;
  private config: WhisperConfig;

  constructor(apiKey: string, config: Partial<WhisperConfig> = {}) {
    this.apiKey = apiKey;
    this.baseUrl = 'https://api.openai.com/v1/audio';
    this.config = { ...DEFAULT_WHISPER_CONFIG, ...config };
  }

  private async fetchWithAuth(endpoint: string, options: RequestInit = {}): Promise<Response> {
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      ...options,
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        ...options.headers,
      },
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error?.message || 'Unknown error');
    }

    return response;
  }

  public async transcribe(
    audio: Blob | File,
    options: Partial<WhisperConfig> = {}
  ): Promise<WhisperResponse> {
    const config = { ...this.config, ...options };
    const formData = new FormData();

    // Add audio file
    formData.append('file', audio, 'audio.webm');
    
    // Add configuration
    formData.append('model', config.model);
    if (config.language) formData.append('language', config.language);
    if (config.prompt) formData.append('prompt', config.prompt);
    formData.append('response_format', config.response_format!);
    formData.append('temperature', config.temperature!.toString());

    const response = await this.fetchWithAuth('/transcriptions', {
      method: 'POST',
      body: formData,
    });

    const data = await response.json();
    return this.parseResponse(data);
  }

  private parseResponse(data: any): WhisperResponse {
    if (this.config.response_format === 'verbose_json') {
      return {
        text: data.text,
        segments: data.segments.map((segment: any): WhisperSegment => ({
          id: segment.id,
          start: segment.start,
          end: segment.end,
          text: segment.text,
          tokens: segment.tokens,
          temperature: segment.temperature,
          avg_logprob: segment.avg_logprob,
          compression_ratio: segment.compression_ratio,
          no_speech_prob: segment.no_speech_prob,
        })),
        language: data.language,
      };
    }

    return {
      text: data.text || data,
    };
  }

  public async translateToEnglish(
    audio: Blob | File,
    options: Partial<WhisperConfig> = {}
  ): Promise<WhisperResponse> {
    return this.transcribe(audio, {
      ...options,
      task: 'translate',
    });
  }
} 