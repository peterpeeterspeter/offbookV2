import {
  Voice,
  VoiceListResponse,
  TextToSpeechRequest,
  TextToSpeechResponse,
  TTSError,
  TTSCacheEntry,
  TTSOptions,
  DEFAULT_TTS_OPTIONS,
} from './elevenlabs-types';

export interface Voice {
  voice_id: string;
  name: string;
  category: string;
}

export interface TTSOptions {
  model_id: string;
  voice_id: string;
  text: string;
  voice_settings?: {
    stability: number;
    similarity_boost: number;
    style: number;
    use_speaker_boost: boolean;
  };
}

export class ElevenLabsClient {
  private apiKey: string;
  private baseUrl: string;
  private cache: Map<string, ArrayBuffer>;

  constructor(apiKey: string) {
    this.apiKey = apiKey;
    this.baseUrl = 'https://api.elevenlabs.io/v1';
    this.cache = new Map();
  }

  private async fetchWithAuth(endpoint: string, options: RequestInit = {}): Promise<Response> {
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      ...options,
      headers: {
        'xi-api-key': this.apiKey,
        'Content-Type': 'application/json',
        ...options.headers,
      },
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail?.message || 'Unknown error');
    }

    return response;
  }

  public async getVoices(): Promise<Voice[]> {
    const response = await this.fetchWithAuth('/voices');
    return response.json();
  }

  private getCacheKey(options: TTSOptions): string {
    return `${options.voice_id}-${options.text}-${JSON.stringify(options.voice_settings)}`;
  }

  public async textToSpeech(options: TTSOptions): Promise<ArrayBuffer> {
    const cacheKey = this.getCacheKey(options);
    
    // Check cache first
    const cached = this.cache.get(cacheKey);
    if (cached) {
      return cached;
    }

    const response = await this.fetchWithAuth(`/text-to-speech/${options.voice_id}`, {
      method: 'POST',
      body: JSON.stringify({
        text: options.text,
        model_id: options.model_id,
        voice_settings: options.voice_settings,
      }),
    });

    const audioData = await response.arrayBuffer();
    
    // Cache the result
    this.cache.set(cacheKey, audioData);
    
    return audioData;
  }

  public async textToSpeechStream(options: TTSOptions): Promise<ReadableStream> {
    const response = await this.fetchWithAuth(`/text-to-speech/${options.voice_id}/stream`, {
      method: 'POST',
      body: JSON.stringify({
        text: options.text,
        model_id: options.model_id,
        voice_settings: options.voice_settings,
      }),
    });

    return response.body!;
  }

  public clearCache(): void {
    this.cache.clear();
  }

  public removeCacheItem(options: TTSOptions): void {
    const cacheKey = this.getCacheKey(options);
    this.cache.delete(cacheKey);
  }
} 