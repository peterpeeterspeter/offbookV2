export interface Voice {
  voice_id: string;
  name: string;
  category: string;
  description: string | null;
  preview_url: string;
  labels: Record<string, string>;
  settings: VoiceSettings;
}

export interface VoiceSettings {
  stability: number;
  similarity_boost: number;
  style: number;
  use_speaker_boost: boolean;
}

export interface TextToSpeechRequest {
  text: string;
  model_id: string;
  voice_settings?: VoiceSettings;
}

export interface TextToSpeechResponse {
  audio: ArrayBuffer;
  metadata: {
    text: string;
    model_id: string;
    voice_id: string;
    voice_settings: VoiceSettings;
  };
}

export interface VoiceListResponse {
  voices: Voice[];
}

export interface TTSError {
  detail: {
    message: string;
    status: string;
    code: number;
  };
}

export interface TTSCacheEntry {
  audio: ArrayBuffer;
  metadata: {
    text: string;
    model_id: string;
    voice_id: string;
    voice_settings: VoiceSettings;
    timestamp: number;
  };
}

export interface TTSOptions {
  model?: string;
  voice?: string;
  settings?: Partial<VoiceSettings>;
  cache?: boolean;
}

export const DEFAULT_TTS_OPTIONS: TTSOptions = {
  model: 'eleven_multilingual_v2',
  voice: 'pNInz6obpgDQGcFmaJgB', // Adam
  settings: {
    stability: 0.5,
    similarity_boost: 0.75,
    style: 0.5,
    use_speaker_boost: true,
  },
  cache: true,
}; 