const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = 'ApiError';
  }
}

// Get the authentication token from localStorage
const getAuthToken = () => {
  if (typeof window !== 'undefined') {
    return localStorage.getItem('authToken');
  }
  return null;
};

// Create headers with authentication
const createHeaders = (contentType = 'application/json') => {
  const headers: Record<string, string> = {
    'Content-Type': contentType,
    'Accept': 'application/json',
  };
  const token = getAuthToken();
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
};

async function handleResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'An error occurred' }));
    throw new ApiError(response.status, error.message || 'An error occurred');
  }
  return response.json();
}

export interface Script {
  id: string;
  title: string;
  content: string;
  sceneCount: number;
  totalLines: number;
  estimatedDuration: number;
  metadata: Record<string, any>;
  createdAt: string;
  updatedAt: string;
}

export interface Character {
  id: string;
  name: string;
  description: string;
  emotionalProfile: Record<string, number>;
  commonPhrases: string[];
  voiceSettings: Record<string, any>;
}

export const api = {
  // Auth
  async login(username: string, password: string): Promise<{ token: string }> {
    const response = await fetch(`${API_BASE_URL}/auth/token`, {
      method: 'POST',
      headers: createHeaders(),
      credentials: 'include',
      body: JSON.stringify({ username, password }),
    });
    const data = await handleResponse<{ access_token: string }>(response);
    if (data.access_token) {
      localStorage.setItem('authToken', data.access_token);
    }
    return { token: data.access_token };
  },

  async logout() {
    try {
      await fetch(`${API_BASE_URL}/auth/logout`, {
        method: 'POST',
        headers: createHeaders(),
        credentials: 'include',
      });
    } finally {
      localStorage.removeItem('authToken');
    }
  },

  // Scripts
  async getScripts(): Promise<Script[]> {
    const response = await fetch(`${API_BASE_URL}/scripts`, {
      headers: createHeaders(),
      credentials: 'include',
    });
    return handleResponse<Script[]>(response);
  },

  async getScript(id: string): Promise<Script> {
    const response = await fetch(`${API_BASE_URL}/scripts/${id}`, {
      headers: createHeaders(),
      credentials: 'include',
    });
    return handleResponse<Script>(response);
  },

  // Characters
  async getCharacters(scriptId: string): Promise<Character[]> {
    const response = await fetch(`${API_BASE_URL}/scripts/${scriptId}/characters`, {
      headers: createHeaders(),
      credentials: 'include',
    });
    return handleResponse<Character[]>(response);
  },

  async getCharacter(scriptId: string, characterId: string): Promise<Character> {
    const response = await fetch(`${API_BASE_URL}/scripts/${scriptId}/characters/${characterId}`, {
      headers: createHeaders(),
      credentials: 'include',
    });
    return handleResponse<Character>(response);
  },

  // Practice Sessions
  async createPracticeSession(scriptId: string): Promise<{ sessionId: string }> {
    const response = await fetch(`${API_BASE_URL}/sessions`, {
      method: 'POST',
      headers: createHeaders(),
      credentials: 'include',
      body: JSON.stringify({ scriptId }),
    });
    return handleResponse<{ sessionId: string }>(response);
  },

  // Voice Generation
  async generateSpeech(text: string, voiceId: string): Promise<{ audioUrl: string }> {
    const response = await fetch(`${API_BASE_URL}/tts/generate`, {
      method: 'POST',
      headers: createHeaders(),
      credentials: 'include',
      body: JSON.stringify({ text, voiceId }),
    });
    return handleResponse<{ audioUrl: string }>(response);
  },
};
