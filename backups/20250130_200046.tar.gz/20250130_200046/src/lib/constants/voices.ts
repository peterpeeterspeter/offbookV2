// ElevenLabs Voice IDs
// These are example IDs - replace with actual voice IDs from your ElevenLabs account
export const characterVoices: Record<string, string> = {
  "Romeo": "pNInz6obpgDQGcFmaJgB", // Adam - young, passionate male voice
  "Juliet": "EXAVITQu4vr4xnSDxMaL", // Rachel - young female voice
  "Mercutio": "VR6AewLTigWG4xSOukaG", // Antoine - playful male voice
  "Nurse": "ThT5KcBeYPX3keUQqHPh", // Grace - mature female voice
  "Friar Lawrence": "ErXwobaYiN019PkySvjV", // Josh - wise male voice
  // Add more character-voice mappings as needed
}

export interface VoiceSettings {
  stability: number
  similarity_boost: number
  style: number
  use_speaker_boost: boolean
}

// Default voice settings for different emotional states
export const emotionVoiceSettings: Record<string, Partial<VoiceSettings>> = {
  "neutral": {
    stability: 0.75,
    similarity_boost: 0.75,
    style: 0.5,
  },
  "joy": {
    stability: 0.65,
    similarity_boost: 0.8,
    style: 0.7,
  },
  "love": {
    stability: 0.6,
    similarity_boost: 0.85,
    style: 0.8,
  },
  "wonder": {
    stability: 0.7,
    similarity_boost: 0.7,
    style: 0.6,
  },
  "longing": {
    stability: 0.8,
    similarity_boost: 0.9,
    style: 0.4,
  },
  "anger": {
    stability: 0.4,
    similarity_boost: 0.6,
    style: 0.9,
  },
  "sadness": {
    stability: 0.9,
    similarity_boost: 0.8,
    style: 0.3,
  }
}

// Fallback voice settings
export const defaultVoiceSettings: VoiceSettings = {
  stability: 0.75,
  similarity_boost: 0.75,
  style: 0.5,
  use_speaker_boost: true
} 