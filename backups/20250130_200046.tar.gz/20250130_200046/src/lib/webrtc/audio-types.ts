// Audio Node Types
export type AudioNodeType = 
  | 'analyzer'
  | 'destination'
  | 'lowEQ'
  | 'midEQ'
  | 'highEQ'
  | 'compressor'
  | 'makeupGain'
  | 'noiseGate'
  | 'gateAnalyzer'
  | 'reverb'
  | 'reverbGain'
  | 'delay'
  | 'delayFeedback'
  | 'delayMix'
  | 'stereoEnhancer';

// Audio Processing Options
export interface NoiseGateOptions {
  threshold: number;  // dB
  attack: number;     // seconds
  release: number;    // seconds
}

export interface EQSettings {
  lowGain: number;    // dB
  midGain: number;    // dB
  highGain: number;   // dB
  lowFreq: number;    // Hz
  midFreq: number;    // Hz
  highFreq: number;   // Hz
  midQ: number;       // Q factor
}

export interface DynamicsSettings {
  threshold: number;  // dB
  ratio: number;      // compression ratio
  attack: number;     // seconds
  release: number;    // seconds
  makeupGain: number; // dB
}

export interface ReverbSettings {
  enabled: boolean;
  mix: number;        // 0 to 1
  decay: number;      // seconds
  preDelay: number;   // seconds
}

export interface DelaySettings {
  enabled: boolean;
  time: number;       // seconds
  feedback: number;   // 0 to 1
  mix: number;        // 0 to 1
}

export interface StereoSettings {
  enabled: boolean;
  width: number;      // -1 to 1
}

// Main Configuration
export interface AudioEffectsConfig {
  eq: EQSettings;
  dynamics: DynamicsSettings;
  noiseGate: NoiseGateOptions;
  reverb: ReverbSettings;
  delay: DelaySettings;
  stereo: StereoSettings;
  autoGain: boolean;
  echoCancellation: boolean;
}

// Stream Options
export interface AudioStreamOptions {
  sampleRate?: number;
  channelCount?: number;
  latencyHint?: AudioContextLatencyCategory | number;
  effects?: Partial<AudioEffectsConfig>;
}

// Stream State
export interface AudioStreamState {
  isStreaming: boolean;
  isMuted: boolean;
  audioContext: AudioContext | null;
  stream: MediaStream | null;
  error: Error | null;
  audioLevel: number;
  processingEnabled: boolean;
  effects: AudioEffectsConfig;
}

// Events
export type AudioProcessorEvent = 
  | { type: 'error'; error: Error }
  | { type: 'levelUpdate'; level: number }
  | { type: 'stateChange'; state: Partial<AudioStreamState> }
  | { type: 'disposed' };

// Default Configurations
export const DEFAULT_EFFECTS_CONFIG: AudioEffectsConfig = {
  eq: {
    lowGain: 0,
    midGain: 0,
    highGain: 0,
    lowFreq: 320,
    midFreq: 1000,
    highFreq: 3200,
    midQ: 0.5,
  },
  dynamics: {
    threshold: -24,
    ratio: 4,
    attack: 0.003,
    release: 0.25,
    makeupGain: 0,
  },
  noiseGate: {
    threshold: -50,
    attack: 0.01,
    release: 0.1,
  },
  reverb: {
    enabled: false,
    mix: 0.3,
    decay: 2,
    preDelay: 0.1,
  },
  delay: {
    enabled: false,
    time: 0.25,
    feedback: 0.3,
    mix: 0.3,
  },
  stereo: {
    enabled: false,
    width: 0.5,
  },
  autoGain: true,
  echoCancellation: true,
};

export const DEFAULT_STREAM_OPTIONS: AudioStreamOptions = {
  sampleRate: 48000,
  channelCount: 2,
  latencyHint: 'interactive',
  effects: DEFAULT_EFFECTS_CONFIG,
}; 