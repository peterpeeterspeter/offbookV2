"use client"

import { useState, useEffect, useRef } from 'react';
import DailyIframe, { DailyCall } from '@daily-co/daily-js';

interface UseDailyOptions {
  url?: string;
  token?: string;
  onJoined?: () => void;
  onLeft?: () => void;
  onError?: (error: Error) => void;
}

interface UseDailyReturn {
  isLoading: boolean;
  error: Error | null;
  isInCall: boolean;
  participants: any[];
  audioLevel: number;
  joinCall: (roomUrl: string) => Promise<void>;
  leaveCall: () => Promise<void>;
  startRecording: () => Promise<void>;
  stopRecording: () => Promise<void>;
}

export function useDaily({
  url,
  token,
  onJoined,
  onLeft,
  onError,
}: UseDailyOptions = {}): UseDailyReturn {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const [isInCall, setIsInCall] = useState(false);
  const [participants, setParticipants] = useState<any[]>([]);
  const [audioLevel, setAudioLevel] = useState(0);

  const callObject = useRef<DailyCall | null>(null);

  useEffect(() => {
    // Cleanup on unmount
    return () => {
      if (callObject.current) {
        callObject.current.destroy();
      }
    };
  }, []);

  const handleJoinedMeeting = () => {
    setIsInCall(true);
    setIsLoading(false);
    onJoined?.();
  };

  const handleLeftMeeting = () => {
    setIsInCall(false);
    setIsLoading(false);
    onLeft?.();
  };

  const handleError = (error: Error) => {
    setError(error);
    setIsLoading(false);
    onError?.(error);
  };

  const handleParticipantsChange = (event: any) => {
    setParticipants(Object.values(event.participants));
  };

  const joinCall = async (roomUrl: string) => {
    try {
      setIsLoading(true);
      setError(null);

      if (!callObject.current) {
        callObject.current = DailyIframe.createCallObject({
          url: roomUrl,
          token,
          audioSource: true,
          videoSource: false,
        });

        // Set up event listeners
        callObject.current
          .on('joined-meeting', handleJoinedMeeting)
          .on('left-meeting', handleLeftMeeting)
          .on('error', handleError)
          .on('participant-joined', handleParticipantsChange)
          .on('participant-left', handleParticipantsChange);

        // Set up audio level monitoring
        callObject.current.setNetworkTopology({ topology: 'peer' });
        callObject.current.startLocalAudioLevelMonitor({
          callback: (event) => {
            setAudioLevel(event.currentAudioLevel || 0);
          },
        });
      }

      await callObject.current.join();
    } catch (error) {
      handleError(error as Error);
    }
  };

  const leaveCall = async () => {
    try {
      if (callObject.current) {
        await callObject.current.leave();
      }
    } catch (error) {
      handleError(error as Error);
    }
  };

  const startRecording = async () => {
    try {
      if (callObject.current && isInCall) {
        await callObject.current.startRecording();
      }
    } catch (error) {
      handleError(error as Error);
    }
  };

  const stopRecording = async () => {
    try {
      if (callObject.current && isInCall) {
        await callObject.current.stopRecording();
      }
    } catch (error) {
      handleError(error as Error);
    }
  };

  return {
    isLoading,
    error,
    isInCall,
    participants,
    audioLevel,
    joinCall,
    leaveCall,
    startRecording,
    stopRecording,
  };
} 