import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import DailyIframe, { DailyCall } from '@daily-co/daily-js';
import { useToast } from '@/components/ui/use-toast';

interface DailyContextType {
  call: DailyCall | null;
  joinRoom: (roomUrl: string) => Promise<void>;
  leaveRoom: () => Promise<void>;
  isJoined: boolean;
  localAudioLevel: number;
  remoteAudioLevel: number;
  error: Error | null;
}

const DailyContext = createContext<DailyContextType | null>(null);

interface DailyProviderProps {
  children: React.ReactNode;
}

export const DailyProvider: React.FC<DailyProviderProps> = ({ children }) => {
  const [call, setCall] = useState<DailyCall | null>(null);
  const [isJoined, setIsJoined] = useState(false);
  const [localAudioLevel, setLocalAudioLevel] = useState(0);
  const [remoteAudioLevel, setRemoteAudioLevel] = useState(0);
  const [error, setError] = useState<Error | null>(null);
  const { toast } = useToast();

  // Initialize Daily call object
  useEffect(() => {
    const dailyCall = DailyIframe.createCallObject({
      audioSource: true,
      videoSource: false,
      dailyConfig: {
        experimentalChromeVideoMuteLightOff: true,
      },
    });
    setCall(dailyCall);

    return () => {
      dailyCall.destroy();
    };
  }, []);

  // Set up event listeners
  useEffect(() => {
    if (!call) return;

    const handleJoined = () => {
      setIsJoined(true);
      toast({
        title: "Connected to room",
        description: "Successfully joined the audio session",
      });
    };

    const handleLeft = () => {
      setIsJoined(false);
      toast({
        title: "Left room",
        description: "Disconnected from the audio session",
      });
    };

    const handleError = (e: Error) => {
      setError(e);
      toast({
        title: "Connection error",
        description: e.message,
        variant: "destructive",
      });
    };

    // Audio level monitoring
    const handleAudioLevel = () => {
      if (!call) return;
      
      const participants = call.participants();
      const local = participants.local;
      const remote = Object.values(participants).find(p => !p.local);

      if (local?.audioLevel !== undefined) {
        setLocalAudioLevel(local.audioLevel);
      }

      if (remote?.audioLevel !== undefined) {
        setRemoteAudioLevel(remote.audioLevel);
      }
    };

    call.on('joined-meeting', handleJoined);
    call.on('left-meeting', handleLeft);
    call.on('error', handleError);
    call.on('active-speaker-change', handleAudioLevel);
    call.on('network-quality-change', (quality) => {
      if (quality < 2) {
        toast({
          title: "Poor connection",
          description: "Network quality is degraded",
          variant: "warning",
        });
      }
    });

    return () => {
      call.off('joined-meeting', handleJoined);
      call.off('left-meeting', handleLeft);
      call.off('error', handleError);
      call.off('active-speaker-change', handleAudioLevel);
    };
  }, [call, toast]);

  const joinRoom = useCallback(async (roomUrl: string) => {
    if (!call) return;

    try {
      await call.join({ url: roomUrl });
    } catch (e) {
      setError(e as Error);
      throw e;
    }
  }, [call]);

  const leaveRoom = useCallback(async () => {
    if (!call) return;

    try {
      await call.leave();
    } catch (e) {
      setError(e as Error);
      throw e;
    }
  }, [call]);

  return (
    <DailyContext.Provider
      value={{
        call,
        joinRoom,
        leaveRoom,
        isJoined,
        localAudioLevel,
        remoteAudioLevel,
        error,
      }}
    >
      {children}
    </DailyContext.Provider>
  );
};

export const useDaily = () => {
  const context = useContext(DailyContext);
  if (!context) {
    throw new Error('useDaily must be used within a DailyProvider');
  }
  return context;
}; 