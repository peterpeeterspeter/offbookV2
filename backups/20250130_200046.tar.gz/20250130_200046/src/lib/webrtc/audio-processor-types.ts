export interface NoiseGateOptions {
  threshold: number;
  attack: number;
  release: number;
}

export interface EQSettings {
  lowGain: number;
  midGain: number;
  highGain: number;
  lowFreq: number;
  midFreq: number;
  highFreq: number;
  midQ: number;
}

export interface DynamicsSettings {
  threshold: number;
  ratio: number;
  attack: number;
  release: number;
  makeupGain: number;
}

export interface ReverbSettings {
  enabled: boolean;
  mix: number;
  decay: number;
  preDelay: number;
}

export interface DelaySettings {
  enabled: boolean;
  time: number;
  feedback: number;
  mix: number;
}

export interface StereoSettings {
  enabled: boolean;
  width: number;
}

export interface AudioEffectsConfig {
  eq: EQSettings;
  dynamics: DynamicsSettings;
  noiseGate: NoiseGateOptions;
  reverb: ReverbSettings;
  delay: DelaySettings;
  stereo: StereoSettings;
  autoGain: boolean;
  echoCancellation: boolean;
}

export const DEFAULT_EFFECTS_CONFIG: AudioEffectsConfig = {
  eq: {
    lowGain: 0,
    midGain: 0,
    highGain: 0,
    lowFreq: 320,
    midFreq: 1000,
    highFreq: 3200,
    midQ: 0.5,
  },
  dynamics: {
    threshold: -24,
    ratio: 4,
    attack: 0.003,
    release: 0.25,
    makeupGain: 0,
  },
  noiseGate: {
    threshold: -50,
    attack: 0.01,
    release: 0.1,
  },
  reverb: {
    enabled: false,
    mix: 0.3,
    decay: 2,
    preDelay: 0.1,
  },
  delay: {
    enabled: false,
    time: 0.25,
    feedback: 0.3,
    mix: 0.3,
  },
  stereo: {
    enabled: false,
    width: 0.5,
  },
  autoGain: true,
  echoCancellation: true,
}; 