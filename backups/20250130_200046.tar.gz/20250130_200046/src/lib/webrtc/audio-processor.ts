import { EventEmitter } from 'events';
import {
  AudioNodeType,
  AudioEffectsConfig,
  DEFAULT_EFFECTS_CONFIG,
  NoiseGateOptions,
  EQSettings,
  DynamicsSettings,
  ReverbSettings,
  DelaySettings,
  StereoSettings,
  AudioProcessorEvent,
} from './audio-types';

interface AudioNodeConnection {
  from: AudioNode;
  to: AudioNode;
  outputIndex?: number;
  inputIndex?: number;
}

export class AudioProcessor extends EventEmitter {
  private context: AudioContext;
  private nodes: Map<AudioNodeType, AudioNode>;
  private connections: AudioNodeConnection[];
  private config: AudioEffectsConfig;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private destinationNode!: MediaStreamAudioDestinationNode;
  private analyzerNode!: AnalyserNode;
  private active: boolean = false;
  private levelMonitorId?: number;

  constructor(context: AudioContext, config: AudioEffectsConfig = DEFAULT_EFFECTS_CONFIG) {
    super();
    this.context = context;
    this.config = config;
    this.nodes = new Map();
    this.connections = [];

    try {
      this.initializeNodes();
      this.startLevelMonitoring();
    } catch (error) {
      this.emit('error', { type: 'error', error: error as Error });
    }
  }

  private initializeNodes(): void {
    // Create analyzer
    this.analyzerNode = this.context.createAnalyser();
    this.analyzerNode.fftSize = 2048;
    this.nodes.set('analyzer', this.analyzerNode);

    // Create destination
    this.destinationNode = this.context.createMediaStreamDestination();
    this.nodes.set('destination', this.destinationNode);

    // Initialize processing chain
    this.createEQNodes();
    this.createDynamicsNodes();
    this.createNoiseGateNodes();
    this.createEffectNodes();
    this.connectNodes();
  }

  private createEQNodes(): void {
    const { eq } = this.config;

    const lowEQ = this.context.createBiquadFilter();
    lowEQ.type = 'lowshelf';
    lowEQ.frequency.value = eq.lowFreq;
    lowEQ.gain.value = eq.lowGain;
    this.nodes.set('lowEQ', lowEQ);

    const midEQ = this.context.createBiquadFilter();
    midEQ.type = 'peaking';
    midEQ.frequency.value = eq.midFreq;
    midEQ.Q.value = eq.midQ;
    midEQ.gain.value = eq.midGain;
    this.nodes.set('midEQ', midEQ);

    const highEQ = this.context.createBiquadFilter();
    highEQ.type = 'highshelf';
    highEQ.frequency.value = eq.highFreq;
    highEQ.gain.value = eq.highGain;
    this.nodes.set('highEQ', highEQ);
  }

  private createDynamicsNodes(): void {
    const { dynamics } = this.config;

    const compressor = this.context.createDynamicsCompressor();
    compressor.threshold.value = dynamics.threshold;
    compressor.ratio.value = dynamics.ratio;
    compressor.attack.value = dynamics.attack;
    compressor.release.value = dynamics.release;
    this.nodes.set('compressor', compressor);

    const makeupGain = this.context.createGain();
    makeupGain.gain.value = this.dbToLinear(dynamics.makeupGain);
    this.nodes.set('makeupGain', makeupGain);
  }

  private createNoiseGateNodes(): void {
    const gate = this.context.createGain();
    gate.gain.value = 1.0;
    this.nodes.set('noiseGate', gate);

    const gateAnalyzer = this.context.createAnalyser();
    gateAnalyzer.fftSize = 256;
    this.nodes.set('gateAnalyzer', gateAnalyzer);
  }

  private async createEffectNodes(): Promise<void> {
    const { reverb, delay, stereo } = this.config;

    // Reverb
    const reverbNode = this.context.createConvolver();
    await this.createReverbImpulse(reverbNode);
    this.nodes.set('reverb', reverbNode);

    const reverbGain = this.context.createGain();
    reverbGain.gain.value = reverb.enabled ? reverb.mix : 0;
    this.nodes.set('reverbGain', reverbGain);

    // Delay
    const delayNode = this.context.createDelay(5.0);
    delayNode.delayTime.value = delay.time;
    this.nodes.set('delay', delayNode);

    const delayFeedback = this.context.createGain();
    delayFeedback.gain.value = delay.feedback;
    this.nodes.set('delayFeedback', delayFeedback);

    const delayMix = this.context.createGain();
    delayMix.gain.value = delay.enabled ? delay.mix : 0;
    this.nodes.set('delayMix', delayMix);

    // Stereo
    const stereoEnhancer = this.context.createStereoPanner();
    stereoEnhancer.pan.value = stereo.enabled ? stereo.width : 0;
    this.nodes.set('stereoEnhancer', stereoEnhancer);
  }

  private async createReverbImpulse(reverbNode: ConvolverNode): Promise<void> {
    const { reverb } = this.config;
    const length = this.context.sampleRate * reverb.decay;
    const impulse = this.context.createBuffer(2, length, this.context.sampleRate);

    for (let channel = 0; channel < 2; channel++) {
      const channelData = impulse.getChannelData(channel);
      for (let i = 0; i < length; i++) {
        channelData[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, reverb.decay);
      }
    }

    reverbNode.buffer = impulse;
  }

  private connectNodes(): void {
    this.connections = [];

    // Main signal path
    this.connect('lowEQ', 'midEQ');
    this.connect('midEQ', 'highEQ');
    this.connect('highEQ', 'compressor');
    this.connect('compressor', 'makeupGain');
    this.connect('makeupGain', 'noiseGate');

    // Effects chains
    this.connect('noiseGate', 'reverb');
    this.connect('reverb', 'reverbGain');
    this.connect('reverbGain', 'stereoEnhancer');

    this.connect('noiseGate', 'delay');
    this.connect('delay', 'delayFeedback');
    this.connect('delayFeedback', 'delay');
    this.connect('delay', 'delayMix');
    this.connect('delayMix', 'stereoEnhancer');

    // Output chain
    this.connect('stereoEnhancer', 'analyzer');
    this.connect('analyzer', 'destination');
  }

  private connect(fromId: AudioNodeType, toId: AudioNodeType, outputIndex?: number, inputIndex?: number): void {
    const fromNode = this.nodes.get(fromId);
    const toNode = this.nodes.get(toId);

    if (!fromNode || !toNode) {
      throw new Error(`Cannot connect nodes: ${fromId} -> ${toId}`);
    }

    if (outputIndex !== undefined && inputIndex !== undefined) {
      fromNode.connect(toNode, outputIndex, inputIndex);
    } else {
      fromNode.connect(toNode);
    }

    this.connections.push({ from: fromNode, to: toNode, outputIndex, inputIndex });
  }

  private startLevelMonitoring(): void {
    const updateLevel = () => {
      if (!this.active) return;

      const dataArray = new Float32Array(this.analyzerNode.frequencyBinCount);
      this.analyzerNode.getFloatTimeDomainData(dataArray);

      const rms = Math.sqrt(dataArray.reduce((acc, val) => acc + val * val, 0) / dataArray.length);
      this.emit('levelUpdate', { type: 'levelUpdate', level: rms });

      this.levelMonitorId = requestAnimationFrame(updateLevel);
    };

    this.levelMonitorId = requestAnimationFrame(updateLevel);
  }

  private stopLevelMonitoring(): void {
    if (this.levelMonitorId) {
      cancelAnimationFrame(this.levelMonitorId);
      this.levelMonitorId = undefined;
    }
  }

  private dbToLinear(db: number): number {
    return Math.pow(10, db / 20);
  }

  public connectSource(stream: MediaStream): void {
    try {
      if (this.sourceNode) {
        this.sourceNode.disconnect();
      }

      this.sourceNode = this.context.createMediaStreamSource(stream);
      this.sourceNode.connect(this.nodes.get('lowEQ')!);
      this.active = true;

      this.emit('stateChange', { 
        type: 'stateChange',
        state: { isStreaming: true, stream: this.getProcessedStream() }
      });
    } catch (error) {
      this.emit('error', { type: 'error', error: error as Error });
    }
  }

  public getAnalyzer(): AnalyserNode {
    return this.analyzerNode;
  }

  public getProcessedStream(): MediaStream {
    return this.destinationNode.stream;
  }

  public updateEQ(settings: Partial<EQSettings>): void {
    try {
      const lowEQ = this.nodes.get('lowEQ') as BiquadFilterNode;
      const midEQ = this.nodes.get('midEQ') as BiquadFilterNode;
      const highEQ = this.nodes.get('highEQ') as BiquadFilterNode;

      if (settings.lowGain !== undefined) lowEQ.gain.value = settings.lowGain;
      if (settings.midGain !== undefined) midEQ.gain.value = settings.midGain;
      if (settings.highGain !== undefined) highEQ.gain.value = settings.highGain;
      if (settings.lowFreq !== undefined) lowEQ.frequency.value = settings.lowFreq;
      if (settings.midFreq !== undefined) midEQ.frequency.value = settings.midFreq;
      if (settings.highFreq !== undefined) highEQ.frequency.value = settings.highFreq;
      if (settings.midQ !== undefined) midEQ.Q.value = settings.midQ;

      this.config.eq = { ...this.config.eq, ...settings };
    } catch (error) {
      this.emit('error', { type: 'error', error: error as Error });
    }
  }

  public updateDynamics(settings: Partial<DynamicsSettings>): void {
    try {
      const compressor = this.nodes.get('compressor') as DynamicsCompressorNode;
      const makeupGain = this.nodes.get('makeupGain') as GainNode;

      if (settings.threshold !== undefined) compressor.threshold.value = settings.threshold;
      if (settings.ratio !== undefined) compressor.ratio.value = settings.ratio;
      if (settings.attack !== undefined) compressor.attack.value = settings.attack;
      if (settings.release !== undefined) compressor.release.value = settings.release;
      if (settings.makeupGain !== undefined) {
        makeupGain.gain.value = this.dbToLinear(settings.makeupGain);
      }

      this.config.dynamics = { ...this.config.dynamics, ...settings };
    } catch (error) {
      this.emit('error', { type: 'error', error: error as Error });
    }
  }

  public updateNoiseGate(options: Partial<NoiseGateOptions>): void {
    try {
      this.config.noiseGate = { ...this.config.noiseGate, ...options };
      
      const gate = this.nodes.get('noiseGate') as GainNode;
      const analyzer = this.nodes.get('gateAnalyzer') as AnalyserNode;
      
      const bufferLength = analyzer.frequencyBinCount;
      const dataArray = new Float32Array(bufferLength);
      analyzer.getFloatTimeDomainData(dataArray);
      
      const rms = Math.sqrt(dataArray.reduce((acc, val) => acc + val * val, 0) / bufferLength);
      const dbFS = 20 * Math.log10(rms);
      
      const threshold = options.threshold ?? this.config.noiseGate.threshold;
      const attack = options.attack ?? this.config.noiseGate.attack;
      const release = options.release ?? this.config.noiseGate.release;
      
      const targetGain = dbFS < threshold ? 0 : 1;
      const timeConstant = targetGain > gate.gain.value ? attack : release;
      
      gate.gain.setTargetAtTime(targetGain, this.context.currentTime, timeConstant);
    } catch (error) {
      this.emit('error', { type: 'error', error: error as Error });
    }
  }

  public updateReverb(settings: Partial<ReverbSettings>): void {
    try {
      const reverbGain = this.nodes.get('reverbGain') as GainNode;
      const reverbNode = this.nodes.get('reverb') as ConvolverNode;

      if (settings.enabled !== undefined) {
        reverbGain.gain.value = settings.enabled ? 
          (settings.mix ?? this.config.reverb.mix) : 0;
      }

      if (settings.mix !== undefined && this.config.reverb.enabled) {
        reverbGain.gain.value = settings.mix;
      }

      if (settings.decay !== undefined || settings.preDelay !== undefined) {
        this.createReverbImpulse(reverbNode);
      }

      this.config.reverb = { ...this.config.reverb, ...settings };
    } catch (error) {
      this.emit('error', { type: 'error', error: error as Error });
    }
  }

  public updateDelay(settings: Partial<DelaySettings>): void {
    try {
      const delayNode = this.nodes.get('delay') as DelayNode;
      const delayFeedback = this.nodes.get('delayFeedback') as GainNode;
      const delayMix = this.nodes.get('delayMix') as GainNode;

      if (settings.enabled !== undefined) {
        delayMix.gain.value = settings.enabled ? 
          (settings.mix ?? this.config.delay.mix) : 0;
      }

      if (settings.time !== undefined) delayNode.delayTime.value = settings.time;
      if (settings.feedback !== undefined) delayFeedback.gain.value = settings.feedback;
      if (settings.mix !== undefined && this.config.delay.enabled) {
        delayMix.gain.value = settings.mix;
      }

      this.config.delay = { ...this.config.delay, ...settings };
    } catch (error) {
      this.emit('error', { type: 'error', error: error as Error });
    }
  }

  public updateStereo(settings: Partial<StereoSettings>): void {
    try {
      const stereoEnhancer = this.nodes.get('stereoEnhancer') as StereoPannerNode;

      if (settings.enabled !== undefined) {
        stereoEnhancer.pan.value = settings.enabled ? 
          (settings.width ?? this.config.stereo.width) : 0;
      }

      if (settings.width !== undefined && this.config.stereo.enabled) {
        stereoEnhancer.pan.value = settings.width;
      }

      this.config.stereo = { ...this.config.stereo, ...settings };
    } catch (error) {
      this.emit('error', { type: 'error', error: error as Error });
    }
  }

  public dispose(): void {
    this.active = false;
    this.stopLevelMonitoring();

    // Disconnect all nodes
    this.connections.forEach(({ from }) => {
      try {
        from.disconnect();
      } catch (error) {
        console.warn('Error disconnecting node:', error);
      }
    });

    if (this.sourceNode) {
      try {
        this.sourceNode.disconnect();
      } catch (error) {
        console.warn('Error disconnecting source node:', error);
      }
    }

    this.emit('disposed', { type: 'disposed' });
  }
} 