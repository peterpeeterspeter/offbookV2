import { useEffect } from 'react';
import { RealtimeChannel } from '@supabase/supabase-js';
import {
  subscribeToScript,
  subscribeToAnalysis,
  subscribeToPerformances,
  Script,
  ScriptAnalysis,
  Performance,
} from './supabase-client';

interface UseRealtimeOptions {
  scriptId: string;
  onScriptUpdate?: (script: Script) => void;
  onAnalysisUpdate?: (analysis: ScriptAnalysis) => void;
  onPerformanceUpdate?: (performance: Performance) => void;
}

export function useRealtime({
  scriptId,
  onScriptUpdate,
  onAnalysisUpdate,
  onPerformanceUpdate,
}: UseRealtimeOptions) {
  useEffect(() => {
    const channels: RealtimeChannel[] = [];

    if (onScriptUpdate) {
      const channel = subscribeToScript(scriptId, onScriptUpdate);
      channels.push(channel);
    }

    if (onAnalysisUpdate) {
      const channel = subscribeToAnalysis(scriptId, onAnalysisUpdate);
      channels.push(channel);
    }

    if (onPerformanceUpdate) {
      const channel = subscribeToPerformances(scriptId, onPerformanceUpdate);
      channels.push(channel);
    }

    // Cleanup subscriptions
    return () => {
      channels.forEach(channel => {
        channel.unsubscribe();
      });
    };
  }, [scriptId, onScriptUpdate, onAnalysisUpdate, onPerformanceUpdate]);
} 