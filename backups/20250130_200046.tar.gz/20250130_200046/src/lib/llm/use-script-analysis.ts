import { useState, useRef } from 'react';
import { useMutation } from '@tanstack/react-query';
import { DeepSeekClient } from './deepseek-client';
import { ScriptAnalysis } from './deepseek-types';

interface UseScriptAnalysisOptions {
  apiKey: string;
  onSuccess?: (analysis: ScriptAnalysis) => void;
  onError?: (error: Error) => void;
}

interface ScriptAnalysisState {
  isAnalyzing: boolean;
  error: Error | null;
  analysis: ScriptAnalysis | null;
}

export function useScriptAnalysis({
  apiKey,
  onSuccess,
  onError,
}: UseScriptAnalysisOptions) {
  const [state, setState] = useState<ScriptAnalysisState>({
    isAnalyzing: false,
    error: null,
    analysis: null,
  });

  const client = useRef<DeepSeekClient | undefined>(undefined);

  // Initialize client if not exists
  if (!client.current) {
    client.current = new DeepSeekClient(apiKey);
  }

  // Analysis mutation
  const { mutate: analyze } = useMutation({
    mutationFn: async (script: string) => {
      setState(prev => ({ ...prev, isAnalyzing: true, error: null }));
      try {
        const analysis = await client.current!.analyzeScript(script);
        setState(prev => ({
          ...prev,
          isAnalyzing: false,
          analysis,
        }));
        onSuccess?.(analysis);
        return analysis;
      } catch (error) {
        setState(prev => ({
          ...prev,
          isAnalyzing: false,
          error: error as Error,
        }));
        onError?.(error as Error);
        throw error;
      }
    },
  });

  return {
    ...state,
    analyze,
  };
} 