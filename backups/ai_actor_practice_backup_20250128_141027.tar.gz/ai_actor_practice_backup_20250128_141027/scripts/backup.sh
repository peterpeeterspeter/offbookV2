#!/bin/bash

# Get current timestamp
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_DIR="backups"
BACKUP_NAME="ai_actor_practice_backup_${TIMESTAMP}"

# Create backups directory if it doesn't exist
mkdir -p $BACKUP_DIR

# Create list of directories to backup
DIRS_TO_BACKUP=(
    "src"
    "public"
    "scripts"
    "backend"
)

# Create list of files to backup
FILES_TO_BACKUP=(
    "package.json"
    "package-lock.json"
    "tsconfig.json"
    "tailwind.config.js"
    "next.config.js"
    "README.md"
    ".env.example"
)

# Create temporary directory for backup
TEMP_DIR="${BACKUP_DIR}/${BACKUP_NAME}"
mkdir -p $TEMP_DIR

# Copy directories
for dir in "${DIRS_TO_BACKUP[@]}"; do
    if [ -d "$dir" ]; then
        echo "Backing up directory: $dir"
        cp -r "$dir" "$TEMP_DIR/"
    fi
done

# Copy files
for file in "${FILES_TO_BACKUP[@]}"; do
    if [ -f "$file" ]; then
        echo "Backing up file: $file"
        cp "$file" "$TEMP_DIR/"
    fi
done

# Create archive
cd $BACKUP_DIR
tar -czf "${BACKUP_NAME}.tar.gz" $BACKUP_NAME
rm -rf $BACKUP_NAME
cd ..

echo "Backup completed: ${BACKUP_DIR}/${BACKUP_NAME}.tar.gz"

# Clean up old backups (keep last 5)
cd $BACKUP_DIR
ls -t *.tar.gz | tail -n +6 | xargs -r rm
cd ..

echo "Backup cleanup completed. Keeping last 5 backups." 