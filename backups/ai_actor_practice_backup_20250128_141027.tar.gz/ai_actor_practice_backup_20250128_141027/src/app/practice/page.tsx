"use client"

import React from 'react';
import { PracticeRoom } from '@/components/practice-session/practice-room';
import { ToastProvider } from '@/components/ui/toast';

export default function PracticePage() {
  return (
    <ToastProvider>
      <main className="container mx-auto p-4">
        <h1 className="text-4xl font-bold mb-8">AI Actor Practice</h1>
        <PracticeRoom
          roomUrl={process.env.NEXT_PUBLIC_DAILY_ROOM_URL || ''}
          userName="Actor"
          onAudioData={(audioData) => {
            // Handle audio data for AI processing
            console.log('Audio data received:', audioData);
          }}
        />
      </main>
    </ToastProvider>
  );
} 