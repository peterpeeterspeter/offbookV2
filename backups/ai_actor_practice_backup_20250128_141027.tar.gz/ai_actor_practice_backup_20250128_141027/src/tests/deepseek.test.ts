import { describe, it, expect, jest, beforeEach, afterEach } from '@jest/globals'
import { detectEmotions, getPerformanceMetrics } from '../services/deepseek'

// Mock environment variables
process.env.REACT_APP_DEEPSEEK_API_KEY = 'test-key'

describe('DeepSeek Service', () => {
  describe('Pipeline Tests', () => {
    it('should process multiple requests in batch', async () => {
      const texts = [
        'I am so happy today!',
        'This makes me really angry.',
        'I feel quite sad about this.',
        'What a surprising turn of events!',
        'Just a neutral statement.'
      ]

      const results = await Promise.all(texts.map(text => detectEmotions(text)))
      
      results.forEach((result, i) => {
        expect(result.suggestions).toBeDefined()
        expect(result.suggestions.length).toBeGreaterThan(0)
        expect(result.suggestions[0].text).toContain(texts[i])
      })

      const metrics = getPerformanceMetrics()
      expect(metrics.pipeline.batchEfficiency).toBeGreaterThan(0)
      expect(metrics.pipeline.queueUtilization).toBeGreaterThanOrEqual(0)
    })

    it('should handle concurrent requests efficiently', async () => {
      const concurrentRequests = 20
      const text = 'Test concurrent processing'
      
      const startTime = Date.now()
      const results = await Promise.all(
        Array(concurrentRequests).fill(null).map(() => detectEmotions(text))
      )
      const endTime = Date.now()

      const metrics = getPerformanceMetrics()
      expect(metrics.pipeline.averageLatency).toBeLessThan(endTime - startTime)
      expect(results.length).toBe(concurrentRequests)
    })

    it('should maintain performance under load', async () => {
      const requests = Array(50).fill(null).map((_, i) => 
        `Test text ${i} with varying length and content for load testing.`
      )

      const startMetrics = getPerformanceMetrics()
      await Promise.all(requests.map(text => detectEmotions(text)))
      const endMetrics = getPerformanceMetrics()

      expect(endMetrics.pipeline.throughput).toBeGreaterThan(0)
      expect(endMetrics.pipeline.errorRate).toBeLessThan(0.1)
    })
  })

  describe('Error Handling', () => {
    it('should fallback to local analysis on API failure', async () => {
      // Temporarily remove API key to simulate failure
      const originalKey = process.env.REACT_APP_DEEPSEEK_API_KEY
      process.env.REACT_APP_DEEPSEEK_API_KEY = ''

      const result = await detectEmotions('Test error handling')
      
      expect(result.suggestions).toBeDefined()
      expect(result.suggestions.length).toBeGreaterThan(0)
      
      process.env.REACT_APP_DEEPSEEK_API_KEY = originalKey
    })

    it('should handle invalid inputs gracefully', async () => {
      const invalidInputs = ['', ' ', '   ', '\n', null, undefined]
      
      for (const input of invalidInputs) {
        const result = await detectEmotions(input as string)
        expect(result.suggestions).toBeDefined()
        expect(Array.isArray(result.suggestions)).toBe(true)
      }
    })
  })

  describe('Caching System', () => {
    it('should cache and retrieve responses', async () => {
      const text = 'Cache test text'
      
      // First request should hit API
      const firstResult = await detectEmotions(text)
      const firstMetrics = getPerformanceMetrics()
      
      // Second request should hit cache
      const secondResult = await detectEmotions(text)
      const secondMetrics = getPerformanceMetrics()

      expect(secondMetrics.cache.hitRate).toBeGreaterThan(firstMetrics.cache.hitRate)
      expect(firstResult).toEqual(secondResult)
    })

    it('should handle cache expiration', async () => {
      const text = 'Expiration test text'
      
      // Mock Date.now for cache testing
      const realDateNow = Date.now
      Date.now = jest.fn(() => 1000)
      
      await detectEmotions(text)
      
      // Simulate time passing
      Date.now = jest.fn(() => 1000 + (8 * 24 * 60 * 60 * 1000)) // 8 days later
      
      const result = await detectEmotions(text)
      expect(result.suggestions).toBeDefined()
      
      // Restore Date.now
      Date.now = realDateNow
    })
  })

  describe('Performance Metrics', () => {
    it('should track comprehensive metrics', async () => {
      const metrics = getPerformanceMetrics()
      
      expect(metrics).toHaveProperty('pipeline')
      expect(metrics).toHaveProperty('cache')
      expect(metrics.pipeline).toHaveProperty('averageLatency')
      expect(metrics.pipeline).toHaveProperty('throughput')
      expect(metrics.pipeline).toHaveProperty('errorRate')
      expect(metrics.cache).toHaveProperty('hitRate')
      expect(metrics.cache).toHaveProperty('totalRequests')
    })

    it('should optimize batch size based on performance', async () => {
      const initialMetrics = getPerformanceMetrics()
      
      // Generate load to trigger batch size adjustments
      await Promise.all(Array(30).fill(null).map((_, i) => 
        detectEmotions(`Performance optimization test ${i}`)
      ))
      
      const finalMetrics = getPerformanceMetrics()
      expect(finalMetrics.pipeline.batchEfficiency)
        .not.toBe(initialMetrics.pipeline.batchEfficiency)
    })
  })
}) 

