import { describe, it, expect, jest, beforeEach, afterEach } from '@jest/globals'
import { synthesizeSpeech, getStreamingMetrics } from '../services/elevenlabs'
import { Emotion, VoiceModifier } from '../types'

// Mock environment variables
process.env.REACT_APP_ELEVENLABS_API_KEY = 'test-key'

// Helper function to create typed mock responses
function createMockResponse(data?: Uint8Array | null, options: ResponseInit = {}): Promise<Response> {
  if (data) {
    return Promise.resolve(new Response(new ReadableStream({
      start(controller) {
        controller.enqueue(data)
        controller.close()
      }
    }), options))
  }
  return Promise.resolve(new Response(null, options))
}

// Mock fetch for testing
const mockFetch = jest.fn().mockImplementation(() => createMockResponse(null)) as jest.MockedFunction<typeof fetch>
global.fetch = mockFetch

describe('ElevenLabs Service', () => {
  beforeEach(() => {
    mockFetch.mockReset()
    mockFetch.mockImplementation(() => createMockResponse(null))
  })

  describe('Streaming Tests', () => {
    it('should create and manage audio streams', async () => {
      mockFetch.mockImplementationOnce(() => 
        createMockResponse(new Uint8Array([1, 2, 3, 4]))
      )

      const stream = await synthesizeSpeech('Test streaming', 'neutral', 5)
      expect(stream).toBeInstanceOf(ReadableStream)

      const metrics = getStreamingMetrics()
      expect(metrics.activeStreams).toBeGreaterThanOrEqual(0)
      expect(metrics.bufferUtilization).toBeGreaterThanOrEqual(0)
    })

    it('should handle streaming errors and retry', async () => {
      let attempts = 0
      mockFetch.mockImplementation(() => {
        attempts++
        if (attempts === 1) {
          return Promise.reject(new Error('Network error'))
        }
        return createMockResponse(new Uint8Array([1, 2, 3, 4]))
      })

      const stream = await synthesizeSpeech('Test error recovery', 'neutral', 5)
      expect(stream).toBeInstanceOf(ReadableStream)

      const metrics = getStreamingMetrics()
      expect(metrics.dropoutCount).toBeGreaterThan(0)
      expect(metrics.recoveryTime).toBeGreaterThan(0)
    })

    it('should optimize buffer size based on latency', async () => {
      const chunks = [
        new Uint8Array([1, 2, 3, 4]),
        new Uint8Array([5, 6, 7, 8]),
        new Uint8Array([9, 10, 11, 12])
      ]

      mockFetch.mockImplementationOnce(() => 
        createMockResponse(Buffer.concat(chunks))
      )

      const stream = await synthesizeSpeech('Test buffer optimization', 'neutral', 5)
      const metrics = getStreamingMetrics()
      
      expect(metrics.streamLatency).toBeGreaterThanOrEqual(0)
      expect(metrics.bufferUtilization).toBeGreaterThanOrEqual(0)
    })
  })

  describe('Voice Selection', () => {
    const testCases: [Emotion, number][] = [
      ['joy', 8],
      ['sadness', 6],
      ['anger', 9],
      ['fear', 7],
      ['surprise', 5],
      ['neutral', 5]
    ]

    testCases.forEach(([emotion, intensity]) => {
      it(`should select appropriate voice for ${emotion} emotion`, async () => {
        mockFetch.mockImplementationOnce(() => 
          createMockResponse(new Uint8Array([1, 2, 3, 4]))
        )

        await synthesizeSpeech(`Test ${emotion} voice`, emotion, intensity)

        const fetchCalls = mockFetch.mock.calls
        expect(fetchCalls.length).toBe(1)
        
        const requestInit = fetchCalls[0][1] as RequestInit
        const requestBody = JSON.parse(requestInit.body as string)
        expect(requestBody.voice_settings).toBeDefined()
        expect(requestBody.voice_settings.stability).toBeDefined()
        expect(requestBody.voice_settings.style).toBeDefined()
      })
    })

    it('should adapt voice selection based on performance', async () => {
      const text = 'Test voice adaptation'
      const emotion: Emotion = 'joy'
      const intensity = 7

      // Simulate multiple calls with varying success
      for (let i = 0; i < 5; i++) {
        mockFetch.mockImplementationOnce(() => {
          if (i % 2 === 0) {
            return Promise.reject(new Error('Voice failed'))
          }
          return createMockResponse(new Uint8Array([1, 2, 3, 4]))
        })

        try {
          await synthesizeSpeech(text, emotion, intensity)
        } catch (error) {
          // Expected for even iterations
        }
      }

      // Check if different voices were selected after failures
      const fetchCalls = mockFetch.mock.calls
      const uniqueVoiceIds = new Set(fetchCalls.map(call => call[0].toString().split('/')[6]))
      expect(uniqueVoiceIds.size).toBeGreaterThan(1)
    })
  })

  describe('Voice Settings', () => {
    it('should apply emotion-specific voice settings', async () => {
      const emotions: Emotion[] = ['joy', 'sadness', 'anger', 'fear', 'surprise', 'neutral']
      const intensity = 7
      const modifier: VoiceModifier = {
        stability: 0.6,
        style: 0.8
      }

      for (const emotion of emotions) {
        mockFetch.mockImplementationOnce(() => 
          createMockResponse(new Uint8Array([1, 2, 3, 4]))
        )

        await synthesizeSpeech('Test voice settings', emotion, intensity, undefined, modifier)

        const fetchCalls = mockFetch.mock.calls
        const lastCall = fetchCalls[fetchCalls.length - 1]
        const requestInit = lastCall[1] as RequestInit
        const requestBody = JSON.parse(requestInit.body as string)
        
        expect(requestBody.voice_settings).toBeDefined()
        expect(requestBody.voice_settings.stability).toBe(modifier.stability)
        expect(requestBody.voice_settings.style).toBe(modifier.style)
      }
    })

    it('should handle intensity variations correctly', async () => {
      const intensities = [1, 5, 10]
      const emotion: Emotion = 'joy'

      for (const intensity of intensities) {
        mockFetch.mockImplementationOnce(() => 
          createMockResponse(new Uint8Array([1, 2, 3, 4]))
        )

        await synthesizeSpeech('Test intensity', emotion, intensity)

        const fetchCalls = mockFetch.mock.calls
        const lastCall = fetchCalls[fetchCalls.length - 1]
        const requestInit = lastCall[1] as RequestInit
        const requestBody = JSON.parse(requestInit.body as string)
        
        expect(requestBody.voice_settings).toBeDefined()
        expect(requestBody.voice_settings.style).toBeDefined()
        if (intensity > 5) {
          expect(requestBody.voice_settings.style).toBeGreaterThan(0.5)
        }
      }
    })
  })

  describe('Error Recovery', () => {
    it('should handle network errors gracefully', async () => {
      mockFetch.mockRejectedValueOnce(new Error('Network error'))

      await expect(synthesizeSpeech('Test network error', 'neutral', 5))
        .rejects.toThrow('Network error')

      const metrics = getStreamingMetrics()
      expect(metrics.dropoutCount).toBeGreaterThan(0)
    })

    it('should handle invalid API responses', async () => {
      mockFetch.mockImplementationOnce(() => 
        createMockResponse(null, { status: 400 })
      )

      await expect(synthesizeSpeech('Test invalid response', 'neutral', 5))
        .rejects.toThrow()
    })

    it('should handle stream interruptions', async () => {
      mockFetch.mockImplementationOnce(() => 
        Promise.resolve(new Response(new ReadableStream({
          start(controller) {
            controller.enqueue(new Uint8Array([1, 2, 3, 4]))
            controller.error(new Error('Stream interrupted'))
          }
        })))
      )

      await expect(synthesizeSpeech('Test stream interruption', 'neutral', 5))
        .rejects.toThrow()

      const metrics = getStreamingMetrics()
      expect(metrics.dropoutCount).toBeGreaterThan(0)
      expect(metrics.recoveryTime).toBeGreaterThan(0)
    })
  })

  describe('Edge Cases', () => {
    it('should handle extremely long text input', async () => {
      const longText = 'a'.repeat(5000) // 5K characters
      mockFetch.mockImplementationOnce(() => 
        createMockResponse(new Uint8Array([1, 2, 3, 4]))
      )

      const stream = await synthesizeSpeech(longText, 'neutral', 5)
      expect(stream).toBeInstanceOf(ReadableStream)

      const metrics = getStreamingMetrics()
      expect(metrics.processingTime).toBeGreaterThan(0)
    })

    it('should handle text with SSML tags', async () => {
      const ssmlText = `
        <speak>
          <prosody rate="slow" pitch="+2st">Hello World!</prosody>
          <break time="1s"/>
          <emphasis level="strong">Important text</emphasis>
        </speak>
      `
      mockFetch.mockImplementationOnce(() => 
        createMockResponse(new Uint8Array([1, 2, 3, 4]))
      )

      const stream = await synthesizeSpeech(ssmlText, 'neutral', 5)
      expect(stream).toBeInstanceOf(ReadableStream)
    })

    it('should handle unstable network conditions', async () => {
      const networkConditions = [
        { latency: 100, chunkSize: 1024 },
        { latency: 500, chunkSize: 512 },
        { latency: 1000, chunkSize: 256 },
        { latency: 2000, chunkSize: 128 }
      ]

      for (const condition of networkConditions) {
        mockFetch.mockImplementationOnce(() => 
          new Promise(resolve => 
            setTimeout(() => 
              resolve(createMockResponse(
                new Uint8Array(condition.chunkSize).fill(1)
              )), 
              condition.latency
            )
          )
        )

        const stream = await synthesizeSpeech('Test network stability', 'neutral', 5)
        expect(stream).toBeInstanceOf(ReadableStream)
      }

      const metrics = getStreamingMetrics()
      expect(metrics.networkLatency).toBeDefined()
      expect(metrics.adaptiveBufferSize).toBeDefined()
    })

    it('should handle concurrent voice changes', async () => {
      const emotions: Emotion[] = ['joy', 'sadness', 'anger', 'fear']
      const intensities = [3, 5, 7, 9]

      // Simulate rapid voice changes
      const promises = emotions.map((emotion, i) => {
        mockFetch.mockImplementationOnce(() => 
          createMockResponse(new Uint8Array([1, 2, 3, 4]))
        )
        return synthesizeSpeech('Test voice change', emotion, intensities[i])
      })

      const streams = await Promise.all(promises)
      streams.forEach(stream => {
        expect(stream).toBeInstanceOf(ReadableStream)
      })

      const metrics = getStreamingMetrics()
      expect(metrics.voiceChangeLatency).toBeDefined()
    })

    it('should handle partial audio data and reconnection', async () => {
      let attemptCount = 0
      mockFetch.mockImplementation(() => {
        attemptCount++
        if (attemptCount === 1) {
          // Simulate partial data then failure
          return Promise.resolve(new Response(new ReadableStream({
            start(controller) {
              controller.enqueue(new Uint8Array([1, 2]))
              controller.error(new Error('Connection lost'))
            }
          })))
        }
        // Successful retry
        return createMockResponse(new Uint8Array([1, 2, 3, 4]))
      })

      const stream = await synthesizeSpeech('Test partial data', 'neutral', 5)
      expect(stream).toBeInstanceOf(ReadableStream)

      const metrics = getStreamingMetrics()
      expect(metrics.reconnectionCount).toBeGreaterThan(0)
      expect(metrics.partialDataSize).toBeGreaterThan(0)
    })

    it('should handle extreme voice settings', async () => {
      const extremeSettings: VoiceModifier[] = [
        { stability: 0.01, style: 0.99 },
        { stability: 0.99, style: 0.01 },
        { stability: 0.5, style: 0 },
        { stability: 1, style: 1 }
      ]

      for (const settings of extremeSettings) {
        mockFetch.mockImplementationOnce(() => 
          createMockResponse(new Uint8Array([1, 2, 3, 4]))
        )

        const stream = await synthesizeSpeech(
          'Test extreme settings',
          'neutral',
          5,
          undefined,
          settings
        )
        expect(stream).toBeInstanceOf(ReadableStream)
      }
    })
  })
}) 
