import { AIServiceManager } from './ai-service-manager';
import { Emotion } from '../../types';

interface AIServiceRequest {
  type: 'ai_service_request';
  service: string;
  action: string;
  data: any;
  session_id: string;
}

interface AIServiceResponse {
  success: boolean;
  data?: any;
  error?: string;
}

export class PipelineServiceHandler {
  private aiManager: AIServiceManager;
  private ws: WebSocket;

  constructor(ws: WebSocket, aiManager: AIServiceManager) {
    this.ws = ws;
    this.aiManager = aiManager;
    this.setupMessageHandler();
  }

  private setupMessageHandler() {
    this.ws.addEventListener('message', async (event) => {
      const request = JSON.parse(event.data) as AIServiceRequest;
      
      if (request.type === 'ai_service_request') {
        try {
          const response = await this.handleAIRequest(request);
          this.sendResponse(response);
        } catch (error) {
          this.sendResponse({
            success: false,
            error: error.message
          });
        }
      }
    });
  }

  private async handleAIRequest(request: AIServiceRequest): Promise<AIServiceResponse> {
    switch (request.service) {
      case 'deepseek':
        return await this.handleDeepSeekRequest(request);
      case 'audioEnhancement':
        return await this.handleAudioEnhancement(request);
      case 'performanceCoach':
        return await this.handlePerformanceCoach(request);
      default:
        throw new Error(`Unknown service: ${request.service}`);
    }
  }

  private async handleDeepSeekRequest(request: AIServiceRequest): Promise<AIServiceResponse> {
    switch (request.action) {
      case 'analyzeEmotion':
        const audioData = new Float32Array(request.data.audioData);
        const analysis = await this.aiManager.analyzePerformance(
          audioData,
          '', // No text needed for pure emotion analysis
          'NEUTRAL' as Emotion, // Default target
          0.5 // Default intensity
        );
        
        return {
          success: true,
          data: {
            emotion: analysis.emotionMatch > 0.7 ? 'JOY' : 'NEUTRAL',
            confidence: analysis.emotionMatch,
            intensity: analysis.intensityMatch,
            features: {
              timing: analysis.timing,
              suggestions: analysis.suggestions
            }
          }
        };
      
      default:
        throw new Error(`Unknown DeepSeek action: ${request.action}`);
    }
  }

  private async handleAudioEnhancement(request: AIServiceRequest): Promise<AIServiceResponse> {
    if (request.action !== 'enhance') {
      throw new Error(`Unknown audio enhancement action: ${request.action}`);
    }

    const audioData = new Float32Array(request.data.audioData);
    const sampleRate = request.data.sampleRate;

    // Apply audio enhancement using Web Audio API
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const buffer = audioContext.createBuffer(1, audioData.length, sampleRate);
    buffer.copyToChannel(audioData, 0);

    // Create processing nodes
    const source = audioContext.createBufferSource();
    source.buffer = buffer;

    const compressor = audioContext.createDynamicsCompressor();
    compressor.threshold.value = -24;
    compressor.knee.value = 30;
    compressor.ratio.value = 12;
    compressor.attack.value = 0.003;
    compressor.release.value = 0.25;

    const gainNode = audioContext.createGain();
    gainNode.gain.value = 1.0;

    // Connect nodes
    source.connect(compressor);
    compressor.connect(gainNode);
    gainNode.connect(audioContext.destination);

    // Process audio
    const enhancedBuffer = await this.processAudioBuffer(source.buffer);
    
    return {
      success: true,
      data: {
        enhancedAudio: Array.from(enhancedBuffer.getChannelData(0))
      }
    };
  }

  private async handlePerformanceCoach(request: AIServiceRequest): Promise<AIServiceResponse> {
    if (request.action !== 'analyzeFeedback') {
      throw new Error(`Unknown performance coach action: ${request.action}`);
    }

    const {
      audio,
      emotion: { detected, target, intensity },
      quality
    } = request.data;

    const audioData = new Float32Array(audio.data);
    const analysis = await this.aiManager.analyzePerformance(
      audioData,
      '', // No text needed for pure performance analysis
      target as Emotion,
      intensity.target
    );

    return {
      success: true,
      data: {
        emotionMatch: analysis.emotionMatch,
        intensityMatch: analysis.intensityMatch,
        timing: analysis.timing,
        suggestions: analysis.suggestions,
        qualityIssues: this.analyzeQualityIssues(quality)
      }
    };
  }

  private analyzeQualityIssues(quality: any): string[] {
    const issues: string[] = [];
    
    if (quality.snr !== null && quality.snr < 15) {
      issues.push('High background noise detected. Try recording in a quieter environment.');
    }
    
    if (quality.clipping_percentage > 1.0) {
      issues.push('Audio clipping detected. Try speaking a bit softer or moving back from the microphone.');
    }
    
    if (quality.peak < 0.3) {
      issues.push('Audio level is too low. Try speaking louder or moving closer to the microphone.');
    }
    
    if (quality.peak > 0.9) {
      issues.push('Audio level is too high. Try speaking softer or moving back from the microphone.');
    }
    
    return issues;
  }

  private async processAudioBuffer(buffer: AudioBuffer): Promise<AudioBuffer> {
    // Create offline context for processing
    const offlineCtx = new OfflineAudioContext(
      1,
      buffer.length,
      buffer.sampleRate
    );

    // Create nodes
    const source = offlineCtx.createBufferSource();
    source.buffer = buffer;

    const compressor = offlineCtx.createDynamicsCompressor();
    const gainNode = offlineCtx.createGain();

    // Connect nodes
    source.connect(compressor);
    compressor.connect(gainNode);
    gainNode.connect(offlineCtx.destination);

    // Start processing
    source.start(0);
    return await offlineCtx.startRendering();
  }

  private sendResponse(response: AIServiceResponse) {
    this.ws.send(JSON.stringify(response));
  }
} 