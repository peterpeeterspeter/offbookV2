import { Emotion } from '../../types';

interface EmotionalFeatures {
  pitch: {
    mean: number;
    variance: number;
    contour: number[];
  };
  energy: {
    mean: number;
    variance: number;
    contour: number[];
  };
  timing: {
    tempo: number;
    rhythm: number[];
  };
}

interface EmotionStyle {
  emotion: Emotion;
  intensity: number;
  features: EmotionalFeatures;
  metadata: {
    confidence: number;
    successRate: number;
    usageCount: number;
  };
}

interface TransferResult {
  sourceFeatures: EmotionalFeatures;
  targetFeatures: EmotionalFeatures;
  transformations: {
    pitch: number[];
    energy: number[];
    timing: number[];
  };
  confidence: number;
}

export class EmotionTransfer {
  private styleBank: Map<string, EmotionStyle[]> = new Map();
  private readonly minConfidence = 0.7;
  private readonly maxStyles = 10;

  constructor() {
    // Initialize with some basic emotion styles
    this.initializeBaseStyles();
  }

  private initializeBaseStyles() {
    const baseStyles: Record<Emotion, EmotionalFeatures> = {
      joy: {
        pitch: {
          mean: 220,
          variance: 0.3,
          contour: [1, 1.2, 1.1, 1.3, 1.2]
        },
        energy: {
          mean: 0.8,
          variance: 0.2,
          contour: [0.7, 0.9, 0.8, 1.0, 0.9]
        },
        timing: {
          tempo: 120,
          rhythm: [1, 0.5, 0.5, 1, 1]
        }
      },
      sadness: {
        pitch: {
          mean: 180,
          variance: 0.1,
          contour: [1, 0.9, 0.85, 0.8, 0.75]
        },
        energy: {
          mean: 0.4,
          variance: 0.1,
          contour: [0.5, 0.4, 0.3, 0.35, 0.3]
        },
        timing: {
          tempo: 80,
          rhythm: [1.2, 1.1, 1.3, 1.2, 1.1]
        }
      },
      anger: {
        pitch: {
          mean: 250,
          variance: 0.4,
          contour: [1.1, 1.3, 1.4, 1.2, 1.3]
        },
        energy: {
          mean: 0.9,
          variance: 0.3,
          contour: [0.8, 1.0, 1.1, 0.9, 1.0]
        },
        timing: {
          tempo: 140,
          rhythm: [0.8, 0.7, 0.6, 0.8, 0.7]
        }
      },
      fear: {
        pitch: {
          mean: 240,
          variance: 0.25,
          contour: [1.0, 1.2, 0.9, 1.1, 0.8]
        },
        energy: {
          mean: 0.5,
          variance: 0.4,
          contour: [0.4, 0.7, 0.3, 0.6, 0.2]
        },
        timing: {
          tempo: 100,
          rhythm: [0.9, 1.1, 0.8, 1.2, 0.7]
        }
      },
      surprise: {
        pitch: {
          mean: 260,
          variance: 0.5,
          contour: [1.0, 1.5, 1.2, 1.1, 1.0]
        },
        energy: {
          mean: 0.7,
          variance: 0.4,
          contour: [0.5, 1.0, 0.8, 0.7, 0.6]
        },
        timing: {
          tempo: 110,
          rhythm: [0.7, 0.4, 0.6, 0.5, 0.8]
        }
      },
      disgust: {
        pitch: {
          mean: 200,
          variance: 0.2,
          contour: [1.1, 0.9, 0.8, 0.7, 0.6]
        },
        energy: {
          mean: 0.6,
          variance: 0.2,
          contour: [0.7, 0.6, 0.5, 0.4, 0.3]
        },
        timing: {
          tempo: 90,
          rhythm: [1.0, 1.1, 0.9, 0.8, 0.7]
        }
      },
      neutral: {
        pitch: {
          mean: 200,
          variance: 0.1,
          contour: [1.0, 1.0, 1.0, 1.0, 1.0]
        },
        energy: {
          mean: 0.5,
          variance: 0.1,
          contour: [0.5, 0.5, 0.5, 0.5, 0.5]
        },
        timing: {
          tempo: 100,
          rhythm: [1.0, 1.0, 1.0, 1.0, 1.0]
        }
      }
    };

    Object.entries(baseStyles).forEach(([emotion, features]) => {
      this.styleBank.set(emotion, [{
        emotion: emotion as Emotion,
        intensity: 7,
        features,
        metadata: {
          confidence: 0.9,
          successRate: 0.9,
          usageCount: 0
        }
      }]);
    });
  }

  async learnStyle(
    emotion: Emotion,
    intensity: number,
    features: EmotionalFeatures,
    performance: {
      success: boolean;
      score: number;
    }
  ) {
    const styles = this.styleBank.get(emotion) || [];
    const newStyle: EmotionStyle = {
      emotion,
      intensity,
      features,
      metadata: {
        confidence: performance.score / 100,
        successRate: performance.success ? 1 : 0,
        usageCount: 1
      }
    };

    // Update existing similar style or add new one
    const similarStyleIndex = styles.findIndex(s => 
      this.calculateStyleSimilarity(s.features, features) > 0.8 &&
      Math.abs(s.intensity - intensity) <= 2
    );

    if (similarStyleIndex >= 0) {
      const existingStyle = styles[similarStyleIndex];
      const updatedStyle = this.mergeStyles(existingStyle, newStyle);
      styles[similarStyleIndex] = updatedStyle;
    } else {
      styles.push(newStyle);
      if (styles.length > this.maxStyles) {
        // Remove least successful/used style
        styles.sort((a, b) => 
          (b.metadata.successRate * b.metadata.usageCount) -
          (a.metadata.successRate * a.metadata.usageCount)
        );
        styles.pop();
      }
    }

    this.styleBank.set(emotion, styles);
  }

  async transferEmotion(
    sourceFeatures: EmotionalFeatures,
    targetEmotion: Emotion,
    targetIntensity: number
  ): Promise<TransferResult> {
    const styles = this.styleBank.get(targetEmotion) || [];
    if (styles.length === 0) {
      throw new Error(`No styles available for emotion: ${targetEmotion}`);
    }

    // Find best matching style for target emotion and intensity
    const bestStyle = styles.reduce((best, current) => {
      const intensityMatch = 1 - Math.abs(current.intensity - targetIntensity) / 10;
      const confidence = current.metadata.confidence * intensityMatch;
      return confidence > best.confidence ? current : best;
    }, styles[0]);

    // Calculate transformations
    const transformations = this.calculateTransformations(
      sourceFeatures,
      bestStyle.features
    );

    // Apply transformations to source features
    const targetFeatures = this.applyTransformations(
      sourceFeatures,
      transformations
    );

    return {
      sourceFeatures,
      targetFeatures,
      transformations,
      confidence: bestStyle.metadata.confidence
    };
  }

  private calculateStyleSimilarity(a: EmotionalFeatures, b: EmotionalFeatures): number {
    const pitchSimilarity = this.calculateFeatureSimilarity(
      a.pitch.contour,
      b.pitch.contour
    );
    const energySimilarity = this.calculateFeatureSimilarity(
      a.energy.contour,
      b.energy.contour
    );
    const timingSimilarity = this.calculateFeatureSimilarity(
      a.timing.rhythm,
      b.timing.rhythm
    );

    return (pitchSimilarity + energySimilarity + timingSimilarity) / 3;
  }

  private calculateFeatureSimilarity(a: number[], b: number[]): number {
    const length = Math.min(a.length, b.length);
    let similarity = 0;

    for (let i = 0; i < length; i++) {
      similarity += 1 - Math.abs(a[i] - b[i]);
    }

    return similarity / length;
  }

  private mergeStyles(existing: EmotionStyle, new_: EmotionStyle): EmotionStyle {
    const totalCount = existing.metadata.usageCount + 1;
    const weight = 1 / totalCount;

    return {
      emotion: existing.emotion,
      intensity: (existing.intensity * (totalCount - 1) + new_.intensity) / totalCount,
      features: {
        pitch: this.interpolateFeatures(existing.features.pitch, new_.features.pitch, weight),
        energy: this.interpolateFeatures(existing.features.energy, new_.features.energy, weight),
        timing: {
          tempo: (existing.features.timing.tempo * (totalCount - 1) + new_.features.timing.tempo) / totalCount,
          rhythm: this.interpolateArrays(existing.features.timing.rhythm, new_.features.timing.rhythm, weight)
        }
      },
      metadata: {
        confidence: (existing.metadata.confidence * (totalCount - 1) + new_.metadata.confidence) / totalCount,
        successRate: (existing.metadata.successRate * existing.metadata.usageCount + (new_.metadata.successRate ? 1 : 0)) / totalCount,
        usageCount: totalCount
      }
    };
  }

  private interpolateFeatures(
    a: { mean: number; variance: number; contour: number[] },
    b: { mean: number; variance: number; contour: number[] },
    weight: number
  ) {
    return {
      mean: a.mean * (1 - weight) + b.mean * weight,
      variance: a.variance * (1 - weight) + b.variance * weight,
      contour: this.interpolateArrays(a.contour, b.contour, weight)
    };
  }

  private interpolateArrays(a: number[], b: number[], weight: number): number[] {
    const length = Math.min(a.length, b.length);
    const result = new Array(length);

    for (let i = 0; i < length; i++) {
      result[i] = a[i] * (1 - weight) + b[i] * weight;
    }

    return result;
  }

  private calculateTransformations(
    source: EmotionalFeatures,
    target: EmotionalFeatures
  ) {
    return {
      pitch: this.calculateFeatureTransformation(
        source.pitch.contour,
        target.pitch.contour
      ),
      energy: this.calculateFeatureTransformation(
        source.energy.contour,
        target.energy.contour
      ),
      timing: this.calculateFeatureTransformation(
        source.timing.rhythm,
        target.timing.rhythm
      )
    };
  }

  private calculateFeatureTransformation(source: number[], target: number[]): number[] {
    const length = Math.min(source.length, target.length);
    const transformation = new Array(length);

    for (let i = 0; i < length; i++) {
      transformation[i] = target[i] / source[i];
    }

    return transformation;
  }

  private applyTransformations(
    source: EmotionalFeatures,
    transformations: TransferResult['transformations']
  ): EmotionalFeatures {
    return {
      pitch: {
        mean: source.pitch.mean,
        variance: source.pitch.variance,
        contour: this.applyFeatureTransformation(
          source.pitch.contour,
          transformations.pitch
        )
      },
      energy: {
        mean: source.energy.mean,
        variance: source.energy.variance,
        contour: this.applyFeatureTransformation(
          source.energy.contour,
          transformations.energy
        )
      },
      timing: {
        tempo: source.timing.tempo,
        rhythm: this.applyFeatureTransformation(
          source.timing.rhythm,
          transformations.timing
        )
      }
    };
  }

  private applyFeatureTransformation(feature: number[], transformation: number[]): number[] {
    const length = Math.min(feature.length, transformation.length);
    const result = new Array(length);

    for (let i = 0; i < length; i++) {
      result[i] = feature[i] * transformation[i];
    }

    return result;
  }
} 