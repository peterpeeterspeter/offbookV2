import { Emotion } from '../../types';

const EMOTION_VOICE_MAP = {
  joy: 'Josh',       // Cheerful, warm voice
  surprise: 'Adam',  // Dynamic, expressive voice
  anger: 'Sam',      // Strong, powerful voice
  fear: 'Antoni',    // Tense, nervous voice
  sadness: 'James',  // Soft, melancholic voice
  disgust: 'Thomas', // Sharp, critical voice
  neutral: 'Daniel'  // Balanced, neutral voice
};

interface TTSOptions {
  emotion: Emotion;
  intensity: number;
  stability?: number;
  similarity_boost?: number;
  style?: number;
  use_speaker_boost?: boolean;
}

interface TTSResponse {
  audioUrl: string;
  duration: number;
  wordTimings: Array<{
    word: string;
    start: number;
    end: number;
  }>;
}

export class ElevenLabsService {
  private apiKey: string;
  private baseUrl = 'https://api.elevenlabs.io/v1';
  private cache: Map<string, TTSResponse>;

  constructor(apiKey: string) {
    this.apiKey = apiKey;
    this.cache = new Map();
  }

  private getCacheKey(text: string, options: TTSOptions): string {
    return `${text}-${options.emotion}-${options.intensity}`;
  }

  private async getVoiceSettings(emotion: Emotion, intensity: number) {
    // Adjust voice settings based on emotion and intensity
    const baseStability = 0.7;  // Higher stability = more consistent
    const baseSimilarity = 0.7; // Higher similarity = closer to original voice

    const settings = {
      stability: baseStability,
      similarity_boost: baseSimilarity,
      style: intensity / 10, // Convert 0-10 scale to 0-1
      use_speaker_boost: true
    };

    switch (emotion) {
      case 'joy':
        settings.stability = baseStability - 0.2; // More variation
        settings.style = Math.min(1, intensity / 8); // More expressive
        break;
      case 'surprise':
        settings.stability = baseStability - 0.3; // Most variation
        settings.style = Math.min(1, intensity / 7); // Very expressive
        break;
      case 'anger':
        settings.stability = baseStability + 0.1; // More controlled
        settings.similarity_boost = baseSimilarity + 0.2; // Stronger character
        break;
      case 'fear':
        settings.stability = baseStability - 0.1; // Slight variation
        settings.style = Math.min(1, intensity / 9); // Moderate expression
        break;
      case 'sadness':
        settings.stability = baseStability + 0.2; // Most stable
        settings.similarity_boost = baseSimilarity + 0.1; // Clear character
        break;
      case 'disgust':
        settings.stability = baseStability;
        settings.similarity_boost = baseSimilarity + 0.15; // Strong character
        break;
      case 'neutral':
        // Use base settings
        break;
    }

    return settings;
  }

  async generateSpeech(text: string, options: TTSOptions): Promise<TTSResponse> {
    const cacheKey = this.getCacheKey(text, options);
    const cached = this.cache.get(cacheKey);
    if (cached) {
      console.log('Using cached TTS response');
      return cached;
    }

    const voiceId = EMOTION_VOICE_MAP[options.emotion];
    const voiceSettings = await this.getVoiceSettings(options.emotion, options.intensity);

    const response = await fetch(`${this.baseUrl}/text-to-speech/${voiceId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'xi-api-key': this.apiKey,
      },
      body: JSON.stringify({
        text,
        model_id: 'eleven_multilingual_v2',
        voice_settings: voiceSettings
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`ElevenLabs API error: ${error.message}`);
    }

    const audioBlob = await response.blob();
    const audioUrl = URL.createObjectURL(audioBlob);

    // Get word timings using the optimization endpoint
    const timingsResponse = await fetch(`${this.baseUrl}/text-to-speech/${voiceId}/optimize`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'xi-api-key': this.apiKey,
      },
      body: JSON.stringify({
        text,
        voice_settings: voiceSettings
      }),
    });

    if (!timingsResponse.ok) {
      console.warn('Failed to get word timings');
    }

    const timings = await timingsResponse.json();
    const result: TTSResponse = {
      audioUrl,
      duration: timings.duration || 0,
      wordTimings: timings.word_timings || []
    };

    // Cache the result
    this.cache.set(cacheKey, result);

    return result;
  }

  async getVoices(): Promise<Array<{ id: string; name: string }>> {
    const response = await fetch(`${this.baseUrl}/voices`, {
      headers: {
        'xi-api-key': this.apiKey,
      },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch voices');
    }

    const data = await response.json();
    return data.voices.map((voice: any) => ({
      id: voice.voice_id,
      name: voice.name
    }));
  }

  clearCache() {
    this.cache.forEach(response => {
      URL.revokeObjectURL(response.audioUrl);
    });
    this.cache.clear();
  }
} 