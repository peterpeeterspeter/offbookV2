import { Emotion } from '../../types';

interface CoachingFeedback {
  score: number;
  feedback: string[];
  corrections: {
    type: 'pitch' | 'tempo' | 'energy' | 'emotion';
    suggestion: string;
    priority: number;
  }[];
  encouragement: string;
}

interface EmotionPattern {
  emotion: Emotion;
  intensity: number;
  features: {
    pitch: number[];
    energy: number[];
    tempo: number;
  };
  performance: {
    score: number;
    feedback: string[];
  };
}

export class PerformanceCoach {
  private learningPatterns: Map<string, EmotionPattern[]> = new Map();
  private currentSession: {
    startTime: number;
    patterns: EmotionPattern[];
    feedback: CoachingFeedback[];
  } | null = null;

  startSession() {
    this.currentSession = {
      startTime: Date.now(),
      patterns: [],
      feedback: []
    };
  }

  endSession(): {
    duration: number;
    averageScore: number;
    improvements: string[];
    patterns: EmotionPattern[];
  } {
    if (!this.currentSession) {
      throw new Error('No active session');
    }

    const duration = Date.now() - this.currentSession.startTime;
    const scores = this.currentSession.feedback.map(f => f.score);
    const averageScore = scores.reduce((a, b) => a + b, 0) / scores.length;

    // Analyze improvements over session
    const improvements = this.analyzeImprovements(this.currentSession.feedback);

    // Store successful patterns for learning
    this.storePatterns(this.currentSession.patterns);

    const result = {
      duration,
      averageScore,
      improvements,
      patterns: this.currentSession.patterns
    };

    this.currentSession = null;
    return result;
  }

  async provideFeedback(
    audioFeatures: {
      pitch: number[];
      energy: number[];
      tempo: number;
    },
    targetEmotion: Emotion,
    targetIntensity: number,
    previousFeedback?: CoachingFeedback
  ): Promise<CoachingFeedback> {
    if (!this.currentSession) {
      throw new Error('No active session');
    }

    // Compare with learned patterns
    const matchingPatterns = this.findMatchingPatterns(targetEmotion, audioFeatures);
    
    // Generate feedback based on patterns and current performance
    const feedback = this.generateFeedback(
      audioFeatures,
      targetEmotion,
      targetIntensity,
      matchingPatterns,
      previousFeedback
    );

    // Store current pattern
    this.currentSession.patterns.push({
      emotion: targetEmotion,
      intensity: targetIntensity,
      features: audioFeatures,
      performance: {
        score: feedback.score,
        feedback: feedback.feedback
      }
    });

    this.currentSession.feedback.push(feedback);
    return feedback;
  }

  private findMatchingPatterns(emotion: Emotion, features: {
    pitch: number[];
    energy: number[];
    tempo: number;
  }): EmotionPattern[] {
    const patterns = this.learningPatterns.get(emotion) || [];
    return patterns.filter(pattern => this.matchesPattern(features, pattern.features));
  }

  private matchesPattern(
    current: { pitch: number[]; energy: number[]; tempo: number },
    pattern: { pitch: number[]; energy: number[]; tempo: number }
  ): boolean {
    // Implement pattern matching logic using dynamic time warping
    // or other similarity measures for time series data
    const pitchSimilarity = this.calculateSimilarity(current.pitch, pattern.pitch);
    const energySimilarity = this.calculateSimilarity(current.energy, pattern.energy);
    const tempoSimilarity = Math.abs(current.tempo - pattern.tempo) / pattern.tempo;

    return (
      pitchSimilarity > 0.8 &&
      energySimilarity > 0.8 &&
      tempoSimilarity < 0.2
    );
  }

  private calculateSimilarity(arr1: number[], arr2: number[]): number {
    // Implement dynamic time warping or other similarity measure
    // This is a simplified example using correlation
    const mean1 = arr1.reduce((a, b) => a + b, 0) / arr1.length;
    const mean2 = arr2.reduce((a, b) => a + b, 0) / arr2.length;

    const variance1 = arr1.reduce((a, b) => a + Math.pow(b - mean1, 2), 0);
    const variance2 = arr2.reduce((a, b) => a + Math.pow(b - mean2, 2), 0);

    let correlation = 0;
    for (let i = 0; i < Math.min(arr1.length, arr2.length); i++) {
      correlation += (arr1[i] - mean1) * (arr2[i] - mean2);
    }

    correlation /= Math.sqrt(variance1 * variance2);
    return (correlation + 1) / 2; // Normalize to [0,1]
  }

  private generateFeedback(
    features: {
      pitch: number[];
      energy: number[];
      tempo: number;
    },
    targetEmotion: Emotion,
    targetIntensity: number,
    matchingPatterns: EmotionPattern[],
    previousFeedback?: CoachingFeedback
  ): CoachingFeedback {
    const feedback: string[] = [];
    const corrections: CoachingFeedback['corrections'] = [];

    // Analyze pitch patterns
    const pitchTrend = this.analyzePitchTrend(features.pitch);
    if (!this.isPitchTrendAppropriate(pitchTrend, targetEmotion)) {
      corrections.push({
        type: 'pitch',
        suggestion: this.getPitchCorrection(targetEmotion, pitchTrend),
        priority: 1
      });
    }

    // Analyze energy patterns
    const energyVariation = this.calculateEnergyVariation(features.energy);
    if (!this.isEnergyAppropriate(energyVariation, targetEmotion, targetIntensity)) {
      corrections.push({
        type: 'energy',
        suggestion: this.getEnergyCorrection(targetEmotion, targetIntensity, energyVariation),
        priority: 2
      });
    }

    // Compare with successful patterns
    if (matchingPatterns.length > 0) {
      const bestPattern = matchingPatterns.reduce((a, b) => 
        a.performance.score > b.performance.score ? a : b
      );
      feedback.push(`Your delivery matches a successful pattern for ${targetEmotion}`);
    }

    // Calculate overall score
    const score = this.calculateScore(features, targetEmotion, targetIntensity, matchingPatterns);

    // Generate encouragement based on progress
    const encouragement = this.generateEncouragement(score, previousFeedback?.score);

    return {
      score,
      feedback,
      corrections: corrections.sort((a, b) => a.priority - b.priority),
      encouragement
    };
  }

  private analyzePitchTrend(pitch: number[]): 'rising' | 'falling' | 'stable' {
    const start = pitch.slice(0, Math.floor(pitch.length / 3));
    const end = pitch.slice(-Math.floor(pitch.length / 3));
    const startMean = start.reduce((a, b) => a + b, 0) / start.length;
    const endMean = end.reduce((a, b) => a + b, 0) / end.length;
    
    const difference = endMean - startMean;
    if (Math.abs(difference) < startMean * 0.1) return 'stable';
    return difference > 0 ? 'rising' : 'falling';
  }

  private isPitchTrendAppropriate(trend: string, emotion: Emotion): boolean {
    const appropriateTrends: Record<Emotion, string[]> = {
      joy: ['rising', 'stable'],
      surprise: ['rising'],
      anger: ['falling', 'stable'],
      fear: ['rising', 'falling'],
      sadness: ['falling'],
      disgust: ['falling', 'stable'],
      neutral: ['stable']
    };
    return appropriateTrends[emotion].includes(trend);
  }

  private getPitchCorrection(emotion: Emotion, currentTrend: string): string {
    const corrections: Record<Emotion, Record<string, string>> = {
      joy: {
        falling: 'Try to maintain a higher, more energetic pitch',
        stable: 'Add some upward pitch variation for more excitement'
      },
      surprise: {
        falling: 'Raise your pitch suddenly for surprise',
        stable: 'Add more sudden pitch changes'
      },
      // Add other emotions...
    };
    return corrections[emotion]?.[currentTrend] || 'Adjust your pitch to match the emotion';
  }

  private calculateEnergyVariation(energy: number[]): number {
    const mean = energy.reduce((a, b) => a + b, 0) / energy.length;
    const variance = energy.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / energy.length;
    return Math.sqrt(variance) / mean;
  }

  private isEnergyAppropriate(
    variation: number,
    emotion: Emotion,
    intensity: number
  ): boolean {
    const appropriateRanges: Record<Emotion, [number, number]> = {
      joy: [0.2, 0.4],
      surprise: [0.3, 0.5],
      anger: [0.25, 0.45],
      fear: [0.15, 0.35],
      sadness: [0.1, 0.25],
      disgust: [0.15, 0.3],
      neutral: [0.1, 0.2]
    };
    
    const [min, max] = appropriateRanges[emotion];
    const scaledMin = min * (intensity / 10);
    const scaledMax = max * (intensity / 10);
    
    return variation >= scaledMin && variation <= scaledMax;
  }

  private getEnergyCorrection(
    emotion: Emotion,
    targetIntensity: number,
    currentVariation: number
  ): string {
    const corrections: Record<Emotion, string[]> = {
      joy: [
        'Add more dynamic variation to your voice',
        'Maintain consistent high energy'
      ],
      surprise: [
        'Create sudden energy spikes',
        'Contrast quiet and loud moments'
      ],
      // Add other emotions...
    };
    
    const index = currentVariation < 0.2 ? 0 : 1;
    return corrections[emotion]?.[index] || 'Adjust your energy level';
  }

  private calculateScore(
    features: {
      pitch: number[];
      energy: number[];
      tempo: number;
    },
    emotion: Emotion,
    intensity: number,
    patterns: EmotionPattern[]
  ): number {
    let score = 0;
    
    // Base score from feature analysis
    if (this.isPitchTrendAppropriate(this.analyzePitchTrend(features.pitch), emotion)) {
      score += 30;
    }
    
    if (this.isEnergyAppropriate(
      this.calculateEnergyVariation(features.energy),
      emotion,
      intensity
    )) {
      score += 30;
    }
    
    // Bonus from matching successful patterns
    if (patterns.length > 0) {
      score += 20;
    }
    
    // Consistency bonus
    score += Math.min(20, patterns.length * 2);
    
    return Math.min(100, score);
  }

  private generateEncouragement(currentScore: number, previousScore?: number): string {
    if (!previousScore) {
      return 'Keep practicing and watch your progress grow!';
    }

    const improvement = currentScore - previousScore;
    if (improvement > 5) {
      return 'Excellent improvement! Keep up the great work!';
    } else if (improvement > 0) {
      return 'You\'re making steady progress. Stay focused!';
    } else {
      return 'Remember, every practice session helps you grow. Try again!';
    }
  }

  private analyzeImprovements(feedback: CoachingFeedback[]): string[] {
    const improvements: string[] = [];
    
    // Analyze score progression
    const scores = feedback.map(f => f.score);
    const averageImprovement = (scores[scores.length - 1] - scores[0]) / scores.length;
    
    if (averageImprovement > 0) {
      improvements.push(`Average performance improved by ${averageImprovement.toFixed(1)} points per attempt`);
    }
    
    // Analyze correction patterns
    const correctionCounts = new Map<string, number>();
    feedback.forEach(f => {
      f.corrections.forEach(c => {
        correctionCounts.set(c.type, (correctionCounts.get(c.type) || 0) + 1);
      });
    });
    
    // Identify most improved areas
    const sortedCorrections = Array.from(correctionCounts.entries())
      .sort((a, b) => b[1] - a[1]);
    
    if (sortedCorrections.length > 0) {
      improvements.push(`Most focused area: ${sortedCorrections[0][0]}`);
    }
    
    return improvements;
  }

  private storePatterns(patterns: EmotionPattern[]) {
    patterns.forEach(pattern => {
      if (pattern.performance.score >= 80) {
        const emotionPatterns = this.learningPatterns.get(pattern.emotion) || [];
        emotionPatterns.push(pattern);
        this.learningPatterns.set(pattern.emotion, emotionPatterns);
      }
    });
  }
} 