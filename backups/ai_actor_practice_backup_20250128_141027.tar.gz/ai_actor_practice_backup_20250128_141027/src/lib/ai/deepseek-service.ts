import { Emotion } from '../../types';

interface EmotionAnalysis {
  emotion: Emotion;
  intensity: number;
  confidence: number;
  explanation: string;
}

interface ScriptAnalysis {
  emotions: EmotionAnalysis[];
  context: string;
  suggestions: string[];
  characterMotivation: string;
}

interface PerformanceAnalysis {
  emotionMatch: number;
  intensityMatch: number;
  timing: {
    pacing: number;
    rhythm: number;
  };
  suggestions: string[];
}

export class DeepSeekService {
  private apiKey: string;
  private baseUrl = 'https://api.deepseek.com/v1';
  private model = 'deepseek-chat';

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  private async callAPI(prompt: string) {
    const response = await fetch(`${this.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.apiKey}`,
      },
      body: JSON.stringify({
        model: this.model,
        messages: [
          {
            role: 'system',
            content: 'You are an expert in script analysis and emotional performance coaching.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 1000
      })
    });

    if (!response.ok) {
      throw new Error('Failed to call DeepSeek API');
    }

    const data = await response.json();
    return data.choices[0].message.content;
  }

  async analyzeScript(text: string): Promise<ScriptAnalysis> {
    const prompt = `Analyze the following script line for emotional content and performance guidance:
    
    "${text}"
    
    Provide:
    1. Emotional analysis (emotion type, intensity 1-10, and confidence)
    2. Context and subtext
    3. Performance suggestions
    4. Character motivation
    
    Format the response as JSON.`;

    const result = await this.callAPI(prompt);
    return JSON.parse(result);
  }

  async analyzePerformance(
    originalText: string,
    audioFeatures: {
      pitch: number[];
      energy: number[];
      tempo: number;
    },
    targetEmotion: Emotion,
    targetIntensity: number
  ): Promise<PerformanceAnalysis> {
    const prompt = `Analyze this performance against the target emotion:
    
    Text: "${originalText}"
    Target Emotion: ${targetEmotion}
    Target Intensity: ${targetIntensity}
    
    Audio Features:
    - Average Pitch: ${Math.average(audioFeatures.pitch)}
    - Energy Variation: ${Math.std(audioFeatures.energy)}
    - Speaking Rate: ${audioFeatures.tempo}
    
    Provide:
    1. Emotion match percentage
    2. Intensity match percentage
    3. Timing analysis (pacing and rhythm)
    4. Specific improvement suggestions
    
    Format the response as JSON.`;

    const result = await this.callAPI(prompt);
    return JSON.parse(result);
  }

  async suggestEmotionalVariations(text: string, currentEmotion: Emotion): Promise<Array<{
    emotion: Emotion;
    intensity: number;
    adaptation: string;
  }>> {
    const prompt = `For this line:
    
    "${text}"
    
    Currently performed with emotion: ${currentEmotion}
    
    Suggest 3 alternative emotional interpretations. For each:
    1. Specify the emotion and intensity (1-10)
    2. Explain how to adapt the delivery
    
    Format the response as JSON array.`;

    const result = await this.callAPI(prompt);
    return JSON.parse(result);
  }

  async generateEmotionGuide(emotion: Emotion, intensity: number): Promise<{
    description: string;
    technicalTips: string[];
    commonPitfalls: string[];
    exercises: string[];
  }> {
    const prompt = `Create a performance guide for expressing:
    
    Emotion: ${emotion}
    Intensity Level: ${intensity}
    
    Include:
    1. Detailed description of the emotion
    2. Technical tips for voice and delivery
    3. Common pitfalls to avoid
    4. Warm-up exercises
    
    Format the response as JSON.`;

    const result = await this.callAPI(prompt);
    return JSON.parse(result);
  }
} 