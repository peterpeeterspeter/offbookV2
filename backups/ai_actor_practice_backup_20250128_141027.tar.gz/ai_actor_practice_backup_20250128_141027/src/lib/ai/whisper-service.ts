interface TranscriptionResult {
  text: string;
  segments: Array<{
    text: string;
    start: number;
    end: number;
    confidence: number;
  }>;
  language: string;
}

interface WhisperOptions {
  language?: string;
  task?: 'transcribe' | 'translate';
  prompt?: string;
  temperature?: number;
  wordTimestamps?: boolean;
}

export class WhisperService {
  private model: any; // Whisper model instance
  private sampleRate = 16000;
  private initialized = false;

  constructor() {
    this.initModel();
  }

  private async initModel() {
    if (typeof window === 'undefined') return;

    try {
      // Load Whisper ONNX model using onnxruntime-web
      const ort = await import('onnxruntime-web');
      this.model = await ort.InferenceSession.create('/models/whisper-base.onnx');
      this.initialized = true;
    } catch (error) {
      console.error('Failed to initialize Whisper model:', error);
      throw error;
    }
  }

  private async preprocessAudio(audioData: Float32Array): Promise<Float32Array> {
    // Ensure audio is at correct sample rate
    if (typeof window === 'undefined') return audioData;

    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    const audioContext = new AudioContext();

    // Create buffer with audio data
    const buffer = audioContext.createBuffer(1, audioData.length, this.sampleRate);
    buffer.copyToChannel(audioData, 0);

    // Apply preprocessing
    const normalizedData = new Float32Array(audioData.length);
    const channelData = buffer.getChannelData(0);
    
    // Normalize audio
    const maxValue = Math.max(...channelData.map(Math.abs));
    for (let i = 0; i < channelData.length; i++) {
      normalizedData[i] = channelData[i] / maxValue;
    }

    return normalizedData;
  }

  async transcribe(audioData: Float32Array, options: WhisperOptions = {}): Promise<TranscriptionResult> {
    if (!this.initialized) {
      await this.initModel();
    }

    // Preprocess audio
    const processedAudio = await this.preprocessAudio(audioData);

    // Prepare model inputs
    const inputTensor = new Float32Array(processedAudio);
    const feeds = {
      input: new Tensor('float32', inputTensor, [1, processedAudio.length])
    };

    // Run inference
    const results = await this.model.run(feeds);

    // Process results
    const outputData = results.output.data;
    const tokens = this.decodeTokens(outputData);

    // Convert tokens to text segments with timing
    const segments = this.alignTextWithTiming(tokens, options.wordTimestamps);

    return {
      text: segments.map(s => s.text).join(' '),
      segments,
      language: this.detectLanguage(tokens)
    };
  }

  private decodeTokens(tokens: number[]): string[] {
    // Implement token decoding logic
    // This would use the Whisper tokenizer vocabulary
    return tokens.map(t => this.vocabulary[t] || '');
  }

  private alignTextWithTiming(tokens: string[], includeWordTimestamps: boolean = false) {
    const segments: Array<{
      text: string;
      start: number;
      end: number;
      confidence: number;
    }> = [];

    // Implement alignment logic
    // This would use the model's attention weights to align text with audio

    return segments;
  }

  private detectLanguage(tokens: string[]): string {
    // Implement language detection logic
    // This would use the model's language detection head
    return 'en';
  }

  async startStreamingRecognition(
    onSegment: (segment: { text: string; isFinal: boolean }) => void,
    options: WhisperOptions = {}
  ) {
    if (!this.initialized) {
      await this.initModel();
    }

    const bufferSize = 4096;
    const buffer: Float32Array[] = [];

    // Set up audio context and processor node
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    const audioContext = new AudioContext();
    
    const processor = audioContext.createScriptProcessor(bufferSize, 1, 1);
    processor.onaudioprocess = (e) => {
      const input = e.inputBuffer.getChannelData(0);
      buffer.push(new Float32Array(input));

      // Process buffer when it reaches sufficient size
      if (buffer.length * bufferSize >= this.sampleRate * 2) { // Process every 2 seconds
        const audioData = this.concatenateBuffers(buffer);
        this.transcribe(audioData, options)
          .then(result => {
            onSegment({
              text: result.text,
              isFinal: false
            });
          })
          .catch(console.error);
        
        // Clear buffer
        buffer.length = 0;
      }
    };

    // Connect to audio input
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const source = audioContext.createMediaStreamSource(stream);
      source.connect(processor);
      processor.connect(audioContext.destination);

      return () => {
        processor.disconnect();
        source.disconnect();
        stream.getTracks().forEach(track => track.stop());
      };
    } catch (error) {
      console.error('Failed to start audio streaming:', error);
      throw error;
    }
  }

  private concatenateBuffers(buffers: Float32Array[]): Float32Array {
    const totalLength = buffers.reduce((sum, buf) => sum + buf.length, 0);
    const result = new Float32Array(totalLength);
    let offset = 0;
    
    for (const buffer of buffers) {
      result.set(buffer, offset);
      offset += buffer.length;
    }
    
    return result;
  }
} 