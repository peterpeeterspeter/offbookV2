import { ElevenLabsService } from './elevenlabs-service';
import { DeepSeekService } from './deepseek-service';
import { WhisperService } from './whisper-service';
import { Emotion } from '../../types';
import { average, standardDeviation, energyContour } from '../utils/math';

interface AIServiceConfig {
  elevenLabsApiKey: string;
  deepSeekApiKey: string;
}

interface AudioAnalysis {
  pitch: number[];
  energy: number[];
  tempo: number;
}

interface PerformanceMetrics {
  emotionMatch: number;
  intensityMatch: number;
  timing: {
    pacing: number;
    rhythm: number;
  };
  suggestions: string[];
}

export class AIServiceManager {
  private elevenLabs: ElevenLabsService;
  private deepSeek: DeepSeekService;
  private whisper: WhisperService;
  private audioContext: AudioContext;

  constructor(config: AIServiceConfig) {
    this.elevenLabs = new ElevenLabsService(config.elevenLabsApiKey);
    this.deepSeek = new DeepSeekService(config.deepSeekApiKey);
    this.whisper = new WhisperService();
    this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
  }

  async generateEmotionalSpeech(text: string, emotion: Emotion, intensity: number) {
    try {
      const ttsResponse = await this.elevenLabs.generateSpeech(text, {
        emotion,
        intensity
      });

      return {
        audioUrl: ttsResponse.audioUrl,
        duration: ttsResponse.duration,
        wordTimings: ttsResponse.wordTimings
      };
    } catch (error) {
      console.error('Failed to generate emotional speech:', error);
      throw error;
    }
  }

  async analyzePerformance(
    audioData: Float32Array,
    text: string,
    targetEmotion: Emotion,
    targetIntensity: number
  ): Promise<PerformanceMetrics> {
    try {
      // Transcribe audio
      const transcription = await this.whisper.transcribe(audioData);

      // Extract audio features
      const audioFeatures = await this.extractAudioFeatures(audioData);

      // Analyze performance
      const analysis = await this.deepSeek.analyzePerformance(
        text,
        audioFeatures,
        targetEmotion,
        targetIntensity
      );

      return analysis;
    } catch (error) {
      console.error('Failed to analyze performance:', error);
      throw error;
    }
  }

  private async extractAudioFeatures(audioData: Float32Array): Promise<AudioAnalysis> {
    // Create audio buffer
    const buffer = this.audioContext.createBuffer(1, audioData.length, this.audioContext.sampleRate);
    buffer.copyToChannel(audioData, 0);

    // Extract features
    const channelData = buffer.getChannelData(0);
    const windowSize = Math.floor(this.audioContext.sampleRate * 0.02); // 20ms windows

    // Calculate energy contour
    const energy = energyContour(channelData, windowSize);

    // Estimate pitch using autocorrelation
    const pitch = await this.estimatePitch(channelData, windowSize);

    // Calculate tempo using onset detection
    const tempo = this.estimateTempo(energy);

    return {
      pitch,
      energy,
      tempo
    };
  }

  private async estimatePitch(audioData: Float32Array, windowSize: number): Promise<number[]> {
    const pitch: number[] = [];
    const minPitch = 50;  // Hz
    const maxPitch = 500; // Hz
    
    for (let i = 0; i < audioData.length - windowSize; i += windowSize) {
      const window = audioData.slice(i, i + windowSize);
      const acf = this.autoCorrelate(window);
      
      // Find peak in ACF
      let maxIndex = 0;
      let maxValue = -Infinity;
      
      for (let j = Math.floor(this.audioContext.sampleRate / maxPitch); 
           j < Math.floor(this.audioContext.sampleRate / minPitch); 
           j++) {
        if (acf[j] > maxValue) {
          maxValue = acf[j];
          maxIndex = j;
        }
      }
      
      const frequency = this.audioContext.sampleRate / maxIndex;
      pitch.push(frequency);
    }
    
    return pitch;
  }

  private autoCorrelate(buffer: Float32Array): Float32Array {
    const correlation = new Float32Array(buffer.length);
    
    for (let lag = 0; lag < buffer.length; lag++) {
      let sum = 0;
      for (let i = 0; i < buffer.length - lag; i++) {
        sum += buffer[i] * buffer[i + lag];
      }
      correlation[lag] = sum;
    }
    
    return correlation;
  }

  private estimateTempo(energy: number[]): number {
    // Find peaks in energy contour
    const peaks = this.findPeaks(energy);
    
    // Calculate average time between peaks
    const peakIntervals: number[] = [];
    for (let i = 1; i < peaks.length; i++) {
      peakIntervals.push(peaks[i] - peaks[i - 1]);
    }
    
    if (peakIntervals.length === 0) return 0;
    
    // Convert to BPM
    const averageInterval = average(peakIntervals);
    const bpm = 60 / (averageInterval / this.audioContext.sampleRate);
    
    return bpm;
  }

  private findPeaks(arr: number[]): number[] {
    const peaks: number[] = [];
    const minPeakDistance = Math.floor(this.audioContext.sampleRate * 0.2); // Minimum 200ms between peaks
    
    for (let i = 1; i < arr.length - 1; i++) {
      if (arr[i] > arr[i - 1] && arr[i] > arr[i + 1]) {
        if (peaks.length === 0 || i - peaks[peaks.length - 1] >= minPeakDistance) {
          peaks.push(i);
        }
      }
    }
    
    return peaks;
  }

  async getEmotionGuide(emotion: Emotion, intensity: number) {
    try {
      return await this.deepSeek.generateEmotionGuide(emotion, intensity);
    } catch (error) {
      console.error('Failed to generate emotion guide:', error);
      throw error;
    }
  }

  async suggestEmotionalVariations(text: string, currentEmotion: Emotion) {
    try {
      return await this.deepSeek.suggestEmotionalVariations(text, currentEmotion);
    } catch (error) {
      console.error('Failed to suggest emotional variations:', error);
      throw error;
    }
  }

  clearCache() {
    this.elevenLabs.clearCache();
  }
} 