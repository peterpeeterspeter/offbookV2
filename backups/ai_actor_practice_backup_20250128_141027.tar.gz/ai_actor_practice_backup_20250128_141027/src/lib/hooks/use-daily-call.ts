import { useEffect, useRef, useState, useCallback } from 'react';
import DailyIframe, { DailyCall } from '@daily-co/daily-js';
import { DailyEventObject, DailyEventObjectAppMessage } from '@daily-co/daily-js';

interface DailyCallOptions {
  url: string;
  userName?: string;
  audioOnly?: boolean;
  onJoinedMeeting?: () => void;
  onLeftMeeting?: () => void;
  onParticipantJoined?: (participant: any) => void;
  onParticipantLeft?: (participant: any) => void;
  onError?: (error: Error) => void;
  onAudioLevel?: (level: number) => void;
}

interface DailyCallState {
  isJoined: boolean;
  participants: Map<string, any>;
  error: Error | null;
  audioLevel: number;
  isAudioEnabled: boolean;
}

export function useDailyCall(options: DailyCallOptions) {
  const callRef = useRef<DailyCall | null>(null);
  const [state, setState] = useState<DailyCallState>({
    isJoined: false,
    participants: new Map(),
    error: null,
    audioLevel: 0,
    isAudioEnabled: true
  });

  // Initialize Daily call
  useEffect(() => {
    if (!options.url) return;

    try {
      callRef.current = DailyIframe.createCallObject({
        audioSource: true,
        videoSource: !options.audioOnly,
        dailyConfig: {
          experimentalChromeVideoMuteLightOff: true
        }
      });

      // Set up event listeners
      callRef.current
        .on('joined-meeting', handleJoinedMeeting)
        .on('left-meeting', handleLeftMeeting)
        .on('participant-joined', handleParticipantJoined)
        .on('participant-left', handleParticipantLeft)
        .on('error', handleError)
        .on('app-message', handleAppMessage)
        .on('track-started', handleTrackStarted)
        .on('track-stopped', handleTrackStopped);

      // Set up audio level monitoring
      if (options.onAudioLevel) {
        startAudioLevelMonitoring();
      }

      return () => {
        stopAudioLevelMonitoring();
        if (callRef.current) {
          callRef.current.destroy();
        }
      };
    } catch (error) {
      handleError(error);
    }
  }, [options.url]);

  // Join meeting handler
  const handleJoinedMeeting = useCallback(() => {
    setState(prev => ({ ...prev, isJoined: true }));
    options.onJoinedMeeting?.();
  }, [options.onJoinedMeeting]);

  // Left meeting handler
  const handleLeftMeeting = useCallback(() => {
    setState(prev => ({ ...prev, isJoined: false, participants: new Map() }));
    options.onLeftMeeting?.();
  }, [options.onLeftMeeting]);

  // Participant joined handler
  const handleParticipantJoined = useCallback((event: DailyEventObject) => {
    const participant = event.participant;
    setState(prev => {
      const newParticipants = new Map(prev.participants);
      newParticipants.set(participant.session_id, participant);
      return { ...prev, participants: newParticipants };
    });
    options.onParticipantJoined?.(participant);
  }, [options.onParticipantJoined]);

  // Participant left handler
  const handleParticipantLeft = useCallback((event: DailyEventObject) => {
    const participant = event.participant;
    setState(prev => {
      const newParticipants = new Map(prev.participants);
      newParticipants.delete(participant.session_id);
      return { ...prev, participants: newParticipants };
    });
    options.onParticipantLeft?.(participant);
  }, [options.onParticipantLeft]);

  // Error handler
  const handleError = useCallback((error: Error) => {
    setState(prev => ({ ...prev, error }));
    options.onError?.(error);
  }, [options.onError]);

  // App message handler
  const handleAppMessage = useCallback((event: DailyEventObjectAppMessage) => {
    // Handle custom messages between participants
    console.log('Received app message:', event.data);
  }, []);

  // Track started handler
  const handleTrackStarted = useCallback((event: DailyEventObject) => {
    // Handle new audio/video tracks
    console.log('Track started:', event);
  }, []);

  // Track stopped handler
  const handleTrackStopped = useCallback((event: DailyEventObject) => {
    // Handle removed audio/video tracks
    console.log('Track stopped:', event);
  }, []);

  // Audio level monitoring
  const startAudioLevelMonitoring = useCallback(() => {
    if (!callRef.current) return;

    const monitorAudioLevel = () => {
      if (!callRef.current) return;

      const audioLevel = callRef.current.participants()?.local?.audioLevel || 0;
      setState(prev => ({ ...prev, audioLevel }));
      options.onAudioLevel?.(audioLevel);
    };

    const intervalId = setInterval(monitorAudioLevel, 100);
    return () => clearInterval(intervalId);
  }, [options.onAudioLevel]);

  const stopAudioLevelMonitoring = useCallback(() => {
    if (!callRef.current) return;
    // Clear any audio monitoring intervals here
  }, []);

  // Join meeting
  const joinMeeting = useCallback(async () => {
    if (!callRef.current) return;

    try {
      await callRef.current.join({
        url: options.url,
        userName: options.userName
      });
    } catch (error) {
      handleError(error);
    }
  }, [options.url, options.userName]);

  // Leave meeting
  const leaveMeeting = useCallback(async () => {
    if (!callRef.current) return;

    try {
      await callRef.current.leave();
    } catch (error) {
      handleError(error);
    }
  }, []);

  // Toggle audio
  const toggleAudio = useCallback(async () => {
    if (!callRef.current) return;

    try {
      const isEnabled = await callRef.current.setLocalAudio(!state.isAudioEnabled);
      setState(prev => ({ ...prev, isAudioEnabled: isEnabled }));
    } catch (error) {
      handleError(error);
    }
  }, [state.isAudioEnabled]);

  // Send message to other participants
  const sendMessage = useCallback((message: any, to?: string) => {
    if (!callRef.current) return;

    try {
      callRef.current.sendAppMessage(message, to);
    } catch (error) {
      handleError(error);
    }
  }, []);

  return {
    state,
    joinMeeting,
    leaveMeeting,
    toggleAudio,
    sendMessage,
    callObject: callRef.current
  };
} 