import { useEffect, useRef, useState } from 'react';

export function useWebSocket(url: string = process.env.NEXT_PUBLIC_WS_URL || 'ws://localhost:8080') {
  const wsRef = useRef<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const ws = new WebSocket(url);
    wsRef.current = ws;

    ws.addEventListener('open', () => {
      setIsConnected(true);
    });

    ws.addEventListener('close', () => {
      setIsConnected(false);
    });

    return () => {
      ws.close();
    };
  }, [url]);

  return wsRef.current;
} 