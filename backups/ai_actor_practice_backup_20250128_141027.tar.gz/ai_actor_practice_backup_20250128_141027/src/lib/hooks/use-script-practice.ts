import { useState, useCallback, useEffect, useRef } from 'react';
import { ScriptLine } from '../../components/script-display/script-display';
import { useWebSocket } from './use-websocket';
import { AIServiceManager } from '../ai/ai-service-manager';
import { PipelineServiceHandler } from '../ai/pipeline-service-handler';
import { Emotion } from '../../types';

interface ScriptPracticeConfig {
  elevenLabsApiKey: string;
  deepSeekApiKey: string;
  wsUrl?: string;
  lines: ScriptLine[];
  onLineComplete?: (lineId: string) => void;
  onSessionComplete?: () => void;
  onError?: (error: Error) => void;
}

interface ScriptPracticeState {
  currentLineId?: string;
  sessionStartTime?: number;
  currentLineStartTime?: number;
  completedLineIds: string[];
  isPaused: boolean;
}

interface ScriptPracticeReturn {
  isReady: boolean;
  error: string | null;
  setTargetEmotion: (emotion: Emotion, intensity: number) => Promise<void>;
  clearCache: () => void;
  startSession: () => void;
  pauseSession: () => void;
  resumeSession: () => void;
  endSession: () => void;
  selectLine: (lineId: string) => void;
  completeLine: (lineId: string) => void;
  getProgress: () => { completedCount: number; totalCount: number; percentage: number };
  getTimingStats: () => { averageTimePerLine: number; elapsedTime: number };
}

export function useScriptPractice(config: ScriptPracticeConfig): ScriptPracticeReturn {
  const [state, setState] = useState<ScriptPracticeState>({
    completedLineIds: [],
    isPaused: false
  });

  const ws = useWebSocket(config.wsUrl);
  const aiManagerRef = useRef<AIServiceManager | null>(null);
  const pipelineHandlerRef = useRef<PipelineServiceHandler | null>(null);
  const [isReady, setIsReady] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Reset state when lines change
  useEffect(() => {
    setState({
      completedLineIds: [],
      isPaused: false
    });
  }, [config.lines]);

  useEffect(() => {
    if (!ws) return;

    try {
      // Initialize AI service manager
      aiManagerRef.current = new AIServiceManager({
        elevenLabsApiKey: config.elevenLabsApiKey,
        deepSeekApiKey: config.deepSeekApiKey
      });

      // Initialize pipeline service handler
      pipelineHandlerRef.current = new PipelineServiceHandler(
        ws,
        aiManagerRef.current
      );

      setIsReady(true);
    } catch (err) {
      setError(err.message);
      console.error('Failed to initialize script practice:', err);
    }
  }, [ws, config.elevenLabsApiKey, config.deepSeekApiKey]);

  const startSession = useCallback(() => {
    if (config.lines.length === 0) {
      config.onError?.(new Error('No lines available to practice'));
      return;
    }

    setState(prev => ({
      currentLineId: config.lines[0].id,
      sessionStartTime: Date.now(),
      currentLineStartTime: Date.now(),
      isPaused: false
    }));
  }, [config.lines, config.onError]);

  const pauseSession = useCallback(() => {
    setState(prev => ({ ...prev, isPaused: true }));
  }, []);

  const resumeSession = useCallback(() => {
    setState(prev => ({
      ...prev,
      isPaused: false,
      currentLineStartTime: Date.now()
    }));
  }, []);

  const endSession = useCallback(() => {
    setState(prev => ({
      currentLineId: undefined,
      sessionStartTime: undefined,
      currentLineStartTime: undefined,
      isPaused: false
    }));
    config.onSessionComplete?.();
  }, [config.onSessionComplete]);

  const selectLine = useCallback((lineId: string) => {
    const lineExists = config.lines.some(line => line.id === lineId);
    if (!lineExists) {
      config.onError?.(new Error('Invalid line selected'));
      return;
    }

    setState(prev => ({
      ...prev,
      currentLineId: lineId,
      currentLineStartTime: Date.now()
    }));
  }, [config.lines, config.onError]);

  const completeLine = useCallback((lineId: string) => {
    setState(prev => {
      if (prev.completedLineIds.includes(lineId)) {
        return prev;
      }

      const newCompletedLineIds = [...prev.completedLineIds, lineId];
      const currentIndex = config.lines.findIndex(line => line.id === lineId);
      const nextLine = config.lines[currentIndex + 1];

      config.onLineComplete?.(lineId);

      if (newCompletedLineIds.length === config.lines.length) {
        config.onSessionComplete?.();
      }

      return {
        ...prev,
        completedLineIds: newCompletedLineIds,
        currentLineId: nextLine?.id,
        currentLineStartTime: nextLine ? Date.now() : prev.currentLineStartTime
      };
    });
  }, [config.lines, config.onLineComplete, config.onSessionComplete]);

  const getProgress = useCallback(() => {
    const completedCount = state.completedLineIds.length;
    const totalCount = config.lines.length;
    const percentage = totalCount > 0 ? (completedCount / totalCount) * 100 : 0;

    return {
      completedCount,
      totalCount,
      percentage
    };
  }, [state.completedLineIds.length, config.lines.length]);

  const getTimingStats = useCallback(() => {
    const now = Date.now();
    const elapsedTime = state.sessionStartTime
      ? (now - state.sessionStartTime) / 1000
      : 0;

    const completedLines = config.lines.filter(line =>
      state.completedLineIds.includes(line.id)
    );
    const totalDuration = completedLines.reduce(
      (sum, line) => sum + line.duration,
      0
    );
    const averageLineTime =
      completedLines.length > 0 ? totalDuration / completedLines.length : 0;

    return {
      averageTimePerLine: averageLineTime,
      elapsedTime
    };
  }, [state.sessionStartTime, state.completedLineIds, config.lines]);

  const setTargetEmotion = async (emotion: Emotion, intensity: number) => {
    if (!ws) return;

    try {
      await ws.send(JSON.stringify({
        type: 'set_target_emotion',
        emotion,
        intensity
      }));
    } catch (err) {
      setError(err.message);
      console.error('Failed to set target emotion:', err);
    }
  };

  const clearCache = () => {
    if (aiManagerRef.current) {
      aiManagerRef.current.clearCache();
    }
  };

  return {
    isReady,
    error,
    setTargetEmotion,
    clearCache,
    startSession,
    pauseSession,
    resumeSession,
    endSession,
    selectLine,
    completeLine,
    getProgress,
    getTimingStats
  };
} 