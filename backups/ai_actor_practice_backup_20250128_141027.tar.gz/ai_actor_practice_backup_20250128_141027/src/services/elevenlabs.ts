import { Emotion, Voice, TTSOptions, TTSCacheEntry, VoiceModifier, StreamingMetrics } from '../types'

// ... existing cache configuration ...

interface StreamContext {
  isStreaming: boolean
  currentStream: ReadableStream | null
  streamController: ReadableStreamDefaultController | null
  bufferSize: number
  lastChunkTime: number
  retryCount: number
  maxRetries: number
}

class StreamManager {
  private context: StreamContext = {
    isStreaming: false,
    currentStream: null,
    streamController: null,
    bufferSize: 0,
    lastChunkTime: 0,
    retryCount: 0,
    maxRetries: 3
  }

  private metrics: StreamingMetrics = {
    bufferUtilization: 0,
    streamLatency: 0,
    dropoutCount: 0,
    recoveryTime: 0,
    activeStreams: 0
  }

  async startStream(options: TTSOptions): Promise<ReadableStream> {
    if (this.context.isStreaming) {
      await this.stopStream()
    }

    this.context.isStreaming = true
    this.context.retryCount = 0
    this.context.lastChunkTime = Date.now()

    return new ReadableStream({
      start: (controller) => {
        this.context.streamController = controller
        this.metrics.activeStreams++
      },
      cancel: () => {
        this.stopStream()
      }
    })
  }

  async stopStream() {
    if (this.context.streamController) {
      this.context.streamController.close()
      this.context.streamController = null
      this.context.isStreaming = false
      this.metrics.activeStreams--
    }
  }

  async pushAudioChunk(chunk: ArrayBuffer) {
    if (!this.context.streamController) return

    try {
      const now = Date.now()
      this.metrics.streamLatency = now - this.context.lastChunkTime
      this.context.lastChunkTime = now

      this.context.streamController.enqueue(new Uint8Array(chunk))
      this.context.bufferSize += chunk.byteLength
      this.metrics.bufferUtilization = this.context.bufferSize / (32 * 1024) // 32KB target

      // Auto-adjust buffer if needed
      if (this.metrics.streamLatency > 100) { // >100ms latency
        this.context.bufferSize = Math.max(16 * 1024, this.context.bufferSize * 0.8)
      }
    } catch (error) {
      console.error('Stream error:', error)
      this.metrics.dropoutCount++
      await this.handleStreamError()
    }
  }

  private async handleStreamError() {
    const startTime = Date.now()
    
    if (this.context.retryCount < this.context.maxRetries) {
      this.context.retryCount++
      await new Promise(resolve => setTimeout(resolve, 1000 * this.context.retryCount))
      
      // Attempt recovery
      if (this.context.streamController) {
        this.context.streamController.error('Stream interrupted, attempting recovery...')
      }
      
      this.metrics.recoveryTime = Date.now() - startTime
    } else {
      await this.stopStream()
      throw new Error('Stream failed after max retries')
    }
  }

  getMetrics(): StreamingMetrics {
    return this.metrics
  }
}

// Voice selection optimization
class VoiceSelector {
  private emotionProfiles: Map<Emotion, string[]> = new Map([
    ['joy', ['rachel', 'bella', 'antoni']],
    ['sadness', ['james', 'emily', 'elli']],
    ['anger', ['josh', 'sam', 'thomas']],
    ['fear', ['grace', 'charlie', 'michael']],
    ['surprise', ['bella', 'antoni', 'rachel']],
    ['neutral', ['sam', 'emily', 'james']]
  ])

  private voiceScores: Map<string, {
    emotionFit: number
    useCount: number
    lastUsed: number
    errorRate: number
  }> = new Map()

  selectVoice(emotion: Emotion, intensity: number): string {
    const candidates = this.emotionProfiles.get(emotion) || []
    let bestVoice = candidates[0]
    let bestScore = -1

    for (const voiceId of candidates) {
      const stats = this.voiceScores.get(voiceId) || {
        emotionFit: 0.5,
        useCount: 0,
        lastUsed: 0,
        errorRate: 0
      }

      // Score based on multiple factors
      const score = (
        (stats.emotionFit * 0.4) +
        (1 - stats.errorRate) * 0.3 +
        (1 - stats.useCount / 1000) * 0.2 +
        (1 - (Date.now() - stats.lastUsed) / (24 * 60 * 60 * 1000)) * 0.1
      )

      if (score > bestScore) {
        bestScore = score
        bestVoice = voiceId
      }
    }

    // Update voice stats
    const stats = this.voiceScores.get(bestVoice) || {
      emotionFit: 0.5,
      useCount: 0,
      lastUsed: 0,
      errorRate: 0
    }
    stats.useCount++
    stats.lastUsed = Date.now()
    this.voiceScores.set(bestVoice, stats)

    return bestVoice
  }

  updateVoiceStats(voiceId: string, success: boolean, emotionFit: number) {
    const stats = this.voiceScores.get(voiceId) || {
      emotionFit: 0.5,
      useCount: 0,
      lastUsed: Date.now(),
      errorRate: 0
    }

    // Update error rate with decay
    const alpha = 0.1 // Learning rate
    stats.errorRate = stats.errorRate * (1 - alpha) + (success ? 0 : 1) * alpha
    stats.emotionFit = stats.emotionFit * (1 - alpha) + emotionFit * alpha

    this.voiceScores.set(voiceId, stats)
  }
}

// Create instances
const streamManager = new StreamManager()
const voiceSelector = new VoiceSelector()

// Voice settings mapping for emotions
function getVoiceSettings(emotion: Emotion, intensity: number, modifier?: VoiceModifier): TTSOptions {
  const baseSettings: TTSOptions = {
    emotion,
    intensity,
    stability: modifier?.stability ?? 0.5,
    similarity_boost: 0.75,
    style: modifier?.style
  }

  if (!modifier) {
    switch (emotion) {
      case 'joy':
        return {
          ...baseSettings,
          stability: 0.3,
          style: Math.min(1, 0.5 + (intensity * 0.05))
        }
      case 'sadness':
        return {
          ...baseSettings,
          stability: 0.8,
          style: Math.max(0, 0.5 - (intensity * 0.05))
        }
      case 'anger':
        return {
          ...baseSettings,
          stability: 0.2,
          style: Math.min(1, 0.6 + (intensity * 0.04))
        }
      case 'fear':
        return {
          ...baseSettings,
          stability: 0.7,
          style: Math.max(0, 0.4 - (intensity * 0.03))
        }
      case 'surprise':
        return {
          ...baseSettings,
          stability: 0.4,
          style: 0.5 + (Math.random() * 0.2)
        }
      case 'disgust':
        return {
          ...baseSettings,
          stability: 0.6,
          style: Math.max(0, 0.3 - (intensity * 0.02))
        }
      case 'neutral':
      default:
        return baseSettings
    }
  }

  return baseSettings
}

// Update synthesizeSpeech to use streaming and voice selection
export async function synthesizeSpeech(
  text: string,
  emotion: Emotion = 'neutral',
  intensity: number = 5,
  voiceId?: string,
  modifier?: VoiceModifier
): Promise<ReadableStream> {
  if (!process.env.REACT_APP_ELEVENLABS_API_KEY) {
    throw new Error('ElevenLabs API key not configured')
  }

  const selectedVoiceId = voiceId || voiceSelector.selectVoice(emotion, intensity)
  const options = { ...getVoiceSettings(emotion, intensity, modifier), voiceId: selectedVoiceId }

  // Start stream
  const stream = await streamManager.startStream(options)

  // Begin streaming process
  fetch(`https://api.elevenlabs.io/v1/text-to-speech/${selectedVoiceId}/stream`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'xi-api-key': process.env.REACT_APP_ELEVENLABS_API_KEY
    },
    body: JSON.stringify({
      text,
      model_id: 'eleven_monolingual_v1',
      voice_settings: options
    })
  }).then(async response => {
    if (!response.body) {
      throw new Error('No response body')
    }

    const reader = response.body.getReader()
    let success = true

    try {
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        await streamManager.pushAudioChunk(value.buffer)
      }
    } catch (error) {
      success = false
      console.error('Streaming error:', error)
      throw error
    } finally {
      voiceSelector.updateVoiceStats(
        selectedVoiceId,
        success,
        success ? 0.8 : 0.2
      )
    }
  })

  return stream
}

export function getStreamingMetrics(): StreamingMetrics {
  return streamManager.getMetrics()
}

// ... rest of existing code ... 
