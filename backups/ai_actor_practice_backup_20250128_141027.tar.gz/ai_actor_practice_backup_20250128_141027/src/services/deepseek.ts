import { Emotion } from '../components/EmotionHighlighter'
import OpenAI from 'openai'
import { PerformanceMetrics, PipelineMetrics } from '../types'

// ... existing code ...

// Pipeline integration
interface PipelineContext {
  startTime: number
  batchSize: number
  processingTime: number[]
  queueSize: number
  lastProcessedTimestamp: number
}

class DeepSeekPipeline {
  private context: PipelineContext = {
    startTime: Date.now(),
    batchSize: 10,
    processingTime: [],
    queueSize: 0,
    lastProcessedTimestamp: Date.now()
  }

  private queue: { text: string; resolve: (value: DeepSeekResponse) => void }[] = []
  private isProcessing = false
  private metrics: PipelineMetrics = {
    averageLatency: 0,
    throughput: 0,
    errorRate: 0,
    queueUtilization: 0,
    batchEfficiency: 0
  }

  async enqueue(text: string): Promise<DeepSeekResponse> {
    return new Promise((resolve) => {
      this.queue.push({ text, resolve })
      this.context.queueSize = this.queue.length
      if (!this.isProcessing) {
        this.processBatch()
      }
    })
  }

  private async processBatch() {
    if (this.isProcessing || this.queue.length === 0) return

    this.isProcessing = true
    const batchStartTime = Date.now()
    const batch = this.queue.splice(0, this.context.batchSize)
    
    try {
      const batchPromises = batch.map(async ({ text, resolve }) => {
        const startTime = Date.now()
        try {
          const result = await detectEmotions(text)
          this.context.processingTime.push(Date.now() - startTime)
          resolve(result)
          return { success: true, time: Date.now() - startTime }
        } catch (error) {
          resolve({ suggestions: analyzeTextLocally(text), error: String(error) })
          return { success: false, time: Date.now() - startTime }
        }
      })

      const results = await Promise.all(batchPromises)
      this.updateMetrics(results, Date.now() - batchStartTime)
    } finally {
      this.isProcessing = false
      this.context.lastProcessedTimestamp = Date.now()
      if (this.queue.length > 0) {
        this.processBatch()
      }
    }
  }

  private updateMetrics(results: { success: boolean; time: number }[], batchTime: number) {
    const successCount = results.filter(r => r.success).length
    const totalTime = results.reduce((sum, r) => sum + r.time, 0)

    this.metrics = {
      averageLatency: totalTime / results.length,
      throughput: results.length / (batchTime / 1000),
      errorRate: (results.length - successCount) / results.length,
      queueUtilization: this.context.queueSize / CACHE_CONFIG.maxEntries,
      batchEfficiency: results.length / this.context.batchSize
    }

    // Optimize batch size based on performance
    if (this.metrics.averageLatency > 1500) { // If latency > 1.5s
      this.context.batchSize = Math.max(1, this.context.batchSize - 1)
    } else if (this.metrics.averageLatency < 500 && this.metrics.errorRate < 0.1) {
      this.context.batchSize = Math.min(20, this.context.batchSize + 1)
    }
  }

  getMetrics(): PipelineMetrics {
    return this.metrics
  }
}

// Create singleton instance
const pipeline = new DeepSeekPipeline()

// Update detectEmotions to use pipeline
export async function detectEmotions(text: string): Promise<DeepSeekResponse> {
  if (!process.env.REACT_APP_DEEPSEEK_API_KEY) {
    return { suggestions: analyzeTextLocally(text) }
  }

  // Check cache first
  const cachedResponse = responseCache.get(text)
  if (cachedResponse) {
    console.log('Using cached response')
    return cachedResponse
  }

  return pipeline.enqueue(text)
}

// Export metrics for monitoring
export function getPerformanceMetrics(): PerformanceMetrics {
  return {
    pipeline: pipeline.getMetrics(),
    cache: responseCache.getMetrics()
  }
}

// ... rest of existing code ... 