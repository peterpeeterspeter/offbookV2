import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="flex-1">
      <section className="space-y-6 pb-8 pt-6 md:pb-12 md:pt-10 lg:py-32">
        <div className="container flex max-w-[64rem] flex-col items-center gap-4 text-center">
          <h1 className="font-heading text-3xl sm:text-5xl md:text-6xl lg:text-7xl">
            Practice Acting with AI
          </h1>
          <p className="max-w-[42rem] leading-normal text-muted-foreground sm:text-xl sm:leading-8">
            Improve your acting skills with real-time AI feedback. Practice dialogue delivery,
            emotional expression, and scene work with our advanced AI tools.
          </p>
          <div className="space-x-4">
            <Button size="lg">Get Started</Button>
            <Button size="lg" variant="outline">Try Demo</Button>
          </div>
        </div>
      </section>

      <section className="container space-y-6 py-8 md:py-12 lg:py-24">
        <div className="mx-auto flex max-w-[58rem] flex-col items-center space-y-4 text-center">
          <h2 className="font-heading text-3xl leading-[1.1] sm:text-3xl md:text-6xl">
            Features
          </h2>
          <p className="max-w-[85%] leading-normal text-muted-foreground sm:text-lg sm:leading-7">
            Our platform combines cutting-edge AI technologies to provide comprehensive acting practice.
          </p>
        </div>
        <div className="mx-auto grid justify-center gap-4 sm:grid-cols-2 md:max-w-[64rem] md:grid-cols-3">
          <div className="relative overflow-hidden rounded-lg border bg-background p-2">
            <div className="flex h-[180px] flex-col justify-between rounded-md p-6">
              <div className="space-y-2">
                <h3 className="font-bold">Real-time Feedback</h3>
                <p className="text-sm text-muted-foreground">
                  Get instant feedback on your performance, including emotion analysis and timing suggestions.
                </p>
              </div>
            </div>
          </div>
          <div className="relative overflow-hidden rounded-lg border bg-background p-2">
            <div className="flex h-[180px] flex-col justify-between rounded-md p-6">
              <div className="space-y-2">
                <h3 className="font-bold">Voice Customization</h3>
                <p className="text-sm text-muted-foreground">
                  Practice with AI-generated voices that you can customize for different characters.
                </p>
              </div>
            </div>
          </div>
          <div className="relative overflow-hidden rounded-lg border bg-background p-2">
            <div className="flex h-[180px] flex-col justify-between rounded-md p-6">
              <div className="space-y-2">
                <h3 className="font-bold">Scene Analysis</h3>
                <p className="text-sm text-muted-foreground">
                  Deep analysis of scenes and character emotions to improve your understanding.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
