const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = 'ApiError';
  }
}

async function handleResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'An error occurred' }));
    throw new ApiError(response.status, error.message);
  }
  return response.json();
}

export interface Script {
  id: string;
  title: string;
  content: string;
  sceneCount: number;
  totalLines: number;
  estimatedDuration: number;
  metadata: Record<string, any>;
  createdAt: string;
  updatedAt: string;
}

export interface Character {
  id: string;
  name: string;
  description: string;
  emotionalProfile: Record<string, number>;
  commonPhrases: string[];
  voiceSettings: Record<string, any>;
}

export const api = {
  // Scripts
  async getScripts(): Promise<Script[]> {
    const response = await fetch(`${API_BASE_URL}/scripts`);
    return handleResponse<Script[]>(response);
  },

  async getScript(id: string): Promise<Script> {
    const response = await fetch(`${API_BASE_URL}/scripts/${id}`);
    return handleResponse<Script>(response);
  },

  // Characters
  async getCharacters(scriptId: string): Promise<Character[]> {
    const response = await fetch(`${API_BASE_URL}/scripts/${scriptId}/characters`);
    return handleResponse<Character[]>(response);
  },

  async getCharacter(scriptId: string, characterId: string): Promise<Character> {
    const response = await fetch(`${API_BASE_URL}/scripts/${scriptId}/characters/${characterId}`);
    return handleResponse<Character>(response);
  },

  // Practice Sessions
  async createPracticeSession(scriptId: string): Promise<{ sessionId: string }> {
    const response = await fetch(`${API_BASE_URL}/sessions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ scriptId }),
    });
    return handleResponse<{ sessionId: string }>(response);
  },

  // Voice Generation
  async generateSpeech(text: string, voiceId: string): Promise<{ audioUrl: string }> {
    const response = await fetch(`${API_BASE_URL}/tts/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ text, voiceId }),
    });
    return handleResponse<{ audioUrl: string }>(response);
  },
}; 