import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type Script, type Character } from "@/lib/api";

export function useScripts() {
  return useQuery({
    queryKey: ["scripts"],
    queryFn: () => api.getScripts(),
  });
}

export function useScript(id: string) {
  return useQuery({
    queryKey: ["scripts", id],
    queryFn: () => api.getScript(id),
    enabled: !!id,
  });
}

export function useCharacters(scriptId: string) {
  return useQuery({
    queryKey: ["scripts", scriptId, "characters"],
    queryFn: () => api.getCharacters(scriptId),
    enabled: !!scriptId,
  });
}

export function useCharacter(scriptId: string, characterId: string) {
  return useQuery({
    queryKey: ["scripts", scriptId, "characters", characterId],
    queryFn: () => api.getCharacter(scriptId, characterId),
    enabled: !!scriptId && !!characterId,
  });
}

export function useCreatePracticeSession() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (scriptId: string) => api.createPracticeSession(scriptId),
    onSuccess: () => {
      // Invalidate and refetch sessions list
      queryClient.invalidateQueries({ queryKey: ["sessions"] });
    },
  });
}

export function useGenerateSpeech() {
  return useMutation({
    mutationFn: ({ text, voiceId }: { text: string; voiceId: string }) =>
      api.generateSpeech(text, voiceId),
  });
} 