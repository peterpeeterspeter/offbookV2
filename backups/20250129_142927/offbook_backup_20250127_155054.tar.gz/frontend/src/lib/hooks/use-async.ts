import { useState, useCallback } from "react"

interface AsyncState<T> {
  isLoading: boolean
  error: Error | null
  data: T | null
}

export function useAsync<T>() {
  const [state, setState] = useState<AsyncState<T>>({
    isLoading: false,
    error: null,
    data: null,
  })

  const run = useCallback(async (promise: Promise<T>) => {
    try {
      setState({ isLoading: true, error: null, data: null })
      const data = await promise
      setState({ isLoading: false, error: null, data })
      return data
    } catch (error) {
      setState({ isLoading: false, error: error as Error, data: null })
      throw error
    }
  }, [])

  return { ...state, run }
} 