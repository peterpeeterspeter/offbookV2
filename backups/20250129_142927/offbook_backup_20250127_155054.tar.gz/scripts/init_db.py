#!/usr/bin/env python3
import asyncio
import os
import sys
from pathlib import Path

# Add the project root to the Python path
project_root = Path(__file__).parent.parent
sys.path.append(str(project_root))

from src.database.config import init_db, cleanup_db
from alembic.config import Config
from alembic import command

async def initialize_database():
    """Initialize the database with tables and initial data."""
    try:
        # Create an Alembic configuration
        alembic_cfg = Config("alembic.ini")
        
        # Run migrations
        command.upgrade(alembic_cfg, "head")
        
        # Initialize database
        await init_db()
        
        print("Database initialization completed successfully!")
        
    except Exception as e:
        print(f"Error initializing database: {e}")
        raise
    finally:
        await cleanup_db()

if __name__ == "__main__":
    asyncio.run(initialize_database()) 