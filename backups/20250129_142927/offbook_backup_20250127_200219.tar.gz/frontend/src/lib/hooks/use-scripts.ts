"use client"

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type Script, type Character } from "@/lib/api";
import { VoiceSettings } from "@/lib/constants/voices"

export function useScripts() {
  return useQuery({
    queryKey: ["scripts"],
    queryFn: () => api.getScripts(),
  });
}

export function useScript(id: string) {
  return useQuery({
    queryKey: ["scripts", id],
    queryFn: () => api.getScript(id),
    enabled: !!id,
  });
}

export function useCharacters(scriptId: string) {
  return useQuery({
    queryKey: ["scripts", scriptId, "characters"],
    queryFn: () => api.getCharacters(scriptId),
    enabled: !!scriptId,
  });
}

export function useCharacter(scriptId: string, characterId: string) {
  return useQuery({
    queryKey: ["scripts", scriptId, "characters", characterId],
    queryFn: () => api.getCharacter(scriptId, characterId),
    enabled: !!scriptId && !!characterId,
  });
}

export function useCreatePracticeSession() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (scriptId: string) => api.createPracticeSession(scriptId),
    onSuccess: () => {
      // Invalidate and refetch sessions list
      queryClient.invalidateQueries({ queryKey: ["sessions"] });
    },
  });
}

interface GenerateSpeechParams {
  text: string
  voiceId: string
  stability?: number
  similarity_boost?: number
  style?: number
  use_speaker_boost?: boolean
}

interface GenerateSpeechResult {
  audioUrl: string
  duration: number
}

async function generateSpeech(params: GenerateSpeechParams): Promise<GenerateSpeechResult> {
  const response = await fetch("/api/tts/generate", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(params),
  })

  if (!response.ok) {
    throw new Error("Failed to generate speech")
  }

  const data = await response.json()
  return {
    audioUrl: data.audioUrl,
    duration: data.duration,
  }
}

export function useGenerateSpeech() {
  return useMutation<GenerateSpeechResult, Error, GenerateSpeechParams>({
    mutationFn: generateSpeech,
    onError: (error) => {
      console.error("Speech generation failed:", error)
    },
  })
} 