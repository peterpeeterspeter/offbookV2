import { createClient, SupabaseClient, PostgrestResponse } from '@supabase/supabase-js';

const supabaseUrl = 'https://jgiiizhaookmfwosnfgk.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpnaWlpemhhb29rbWZ3b3NuZmdrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzgwMDEzMDYsImV4cCI6MjA1MzU3NzMwNn0.M2gy02MvvRxVyXkutTQ1sijbhahAJyk1Gck6Fh-TZtI';

export const supabase: SupabaseClient = createClient(supabaseUrl, supabaseKey);

export interface Script {
  id: string;
  title: string;
  content: string;
  user_id: string;
  created_at: string;
  updated_at: string;
  is_public: boolean;
}

export interface ScriptAnalysis {
  id: string;
  script_id: string;
  analysis: Record<string, any>;
  created_at: string;
}

export interface Performance {
  id: string;
  script_id: string;
  user_id: string;
  recording_url: string;
  transcription: string;
  analysis: Record<string, any>;
  created_at: string;
}

export interface RealtimePayload<T> {
  new: T;
  old: T | null;
  eventType: 'INSERT' | 'UPDATE' | 'DELETE';
}

export async function getScript(id: string): Promise<Script | null> {
  const { data, error } = await supabase
    .from('scripts')
    .select('*')
    .eq('id', id)
    .single();

  if (error) throw error;
  return data;
}

export async function saveScript(script: Partial<Script>): Promise<Script> {
  const { data, error } = await supabase
    .from('scripts')
    .upsert(script)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function saveAnalysis(analysis: Partial<ScriptAnalysis>): Promise<ScriptAnalysis> {
  const { data, error } = await supabase
    .from('script_analyses')
    .upsert(analysis)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function savePerformance(performance: Partial<Performance>): Promise<Performance> {
  const { data, error } = await supabase
    .from('performances')
    .upsert(performance)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export function subscribeToScript(scriptId: string, callback: (script: Script) => void) {
  return supabase
    .channel(`script:${scriptId}`)
    .on<Script>(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'scripts',
        filter: `id=eq.${scriptId}`,
      },
      (payload: RealtimePayload<Script>) => callback(payload.new)
    )
    .subscribe();
}

export function subscribeToAnalysis(scriptId: string, callback: (analysis: ScriptAnalysis) => void) {
  return supabase
    .channel(`analysis:${scriptId}`)
    .on<ScriptAnalysis>(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'script_analyses',
        filter: `script_id=eq.${scriptId}`,
      },
      (payload: RealtimePayload<ScriptAnalysis>) => callback(payload.new)
    )
    .subscribe();
}

export function subscribeToPerformances(scriptId: string, callback: (performance: Performance) => void) {
  return supabase
    .channel(`performances:${scriptId}`)
    .on<Performance>(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'performances',
        filter: `script_id=eq.${scriptId}`,
      },
      (payload: RealtimePayload<Performance>) => callback(payload.new)
    )
    .subscribe();
} 