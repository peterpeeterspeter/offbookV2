import {
  DeepSeekConfig,
  DeepSeekResponse,
  Message,
  ScriptAnalysis,
  DEFAULT_DEEPSEEK_CONFIG,
} from './deepseek-types';

export class DeepSeekClient {
  private apiKey: string;
  private baseUrl: string;
  private config: DeepSeekConfig;

  constructor(apiKey: string, config: Partial<DeepSeekConfig> = {}) {
    this.apiKey = apiKey;
    this.baseUrl = 'https://api.deepseek.com/v1';
    this.config = { ...DEFAULT_DEEPSEEK_CONFIG, ...config };
  }

  private async fetchWithAuth(endpoint: string, options: RequestInit = {}): Promise<Response> {
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      ...options,
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
        ...options.headers,
      },
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error?.message || 'Unknown error');
    }

    return response;
  }

  public async complete(messages: Message[]): Promise<DeepSeekResponse> {
    const response = await this.fetchWithAuth('/chat/completions', {
      method: 'POST',
      body: JSON.stringify({
        ...this.config,
        messages,
      }),
    });

    return response.json();
  }

  public async analyzeScript(script: string): Promise<ScriptAnalysis> {
    const systemPrompt = `You are an expert acting coach and script analyst. Analyze the following script for:
1. Emotions - identify key emotions and their intensity
2. Pacing - suggest appropriate speed and timing
3. Characterization - analyze tone, subtext, and character motivation
4. Technical notes - identify areas for emphasis, pauses, and dynamic changes

Provide a structured analysis that can help an actor deliver the best possible performance.`;

    const response = await this.complete([
      { role: 'system', content: systemPrompt },
      { role: 'user', content: script },
    ]);

    try {
      const analysis = JSON.parse(response.choices[0].message.content);
      return this.validateAnalysis(analysis);
    } catch (error) {
      throw new Error('Failed to parse script analysis');
    }
  }

  private validateAnalysis(analysis: any): ScriptAnalysis {
    // Ensure the analysis matches our expected structure
    const validatedAnalysis: ScriptAnalysis = {
      emotions: analysis.emotions?.map((emotion: any) => ({
        name: emotion.name || '',
        intensity: emotion.intensity || 0,
        description: emotion.description || '',
      })) || [],
      pacing: {
        speed: analysis.pacing?.speed || 'medium',
        suggestions: analysis.pacing?.suggestions || [],
      },
      characterization: {
        tone: analysis.characterization?.tone || '',
        subtext: analysis.characterization?.subtext || '',
        motivation: analysis.characterization?.motivation || '',
      },
      technicalNotes: {
        emphasis: analysis.technicalNotes?.emphasis || [],
        pauses: analysis.technicalNotes?.pauses || [],
        dynamics: analysis.technicalNotes?.dynamics || [],
      },
    };

    return validatedAnalysis;
  }
} 