export interface Message {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface DeepSeekConfig {
  model: string;
  messages: Message[];
  temperature?: number;
  max_tokens?: number;
  top_p?: number;
  stream?: boolean;
}

export interface DeepSeekResponse {
  id: string;
  model: string;
  choices: {
    index: number;
    message: Message;
    finish_reason: string;
  }[];
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

export interface ScriptAnalysis {
  emotions: {
    name: string;
    intensity: number;
    description: string;
  }[];
  pacing: {
    speed: 'slow' | 'medium' | 'fast';
    suggestions: string[];
  };
  characterization: {
    tone: string;
    subtext: string;
    motivation: string;
  };
  technicalNotes: {
    emphasis: string[];
    pauses: string[];
    dynamics: string[];
  };
}

export const DEFAULT_DEEPSEEK_CONFIG: DeepSeekConfig = {
  model: 'deepseek-r1',
  messages: [],
  temperature: 0.7,
  max_tokens: 2048,
  top_p: 0.95,
  stream: false,
}; 