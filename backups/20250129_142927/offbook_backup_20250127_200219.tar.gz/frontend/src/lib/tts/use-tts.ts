"use client"

import { useState, useRef, useCallback } from 'react';
import { useMutation } from '@tanstack/react-query';
import { ElevenLabsClient, TTSOptions } from './elevenlabs-client';

interface UseTTSOptions {
  apiKey: string;
  defaultVoiceId?: string;
  defaultModelId?: string;
  onStart?: () => void;
  onComplete?: (audio: ArrayBuffer) => void;
  onError?: (error: Error) => void;
}

interface TTSState {
  isLoading: boolean;
  error: Error | null;
  audio: ArrayBuffer | null;
  isPlaying: boolean;
}

export function useTTS({
  apiKey,
  defaultVoiceId = 'default',
  defaultModelId = 'eleven_multilingual_v2',
  onStart,
  onComplete,
  onError,
}: UseTTSOptions) {
  const [state, setState] = useState<TTSState>({
    isLoading: false,
    error: null,
    audio: null,
    isPlaying: false,
  });

  const client = useRef<ElevenLabsClient>();
  const audioContext = useRef<AudioContext>();
  const audioSource = useRef<AudioBufferSourceNode>();

  // Initialize client if not exists
  if (!client.current) {
    client.current = new ElevenLabsClient(apiKey);
  }

  // Initialize audio context on first interaction
  const initAudioContext = useCallback(() => {
    if (!audioContext.current) {
      audioContext.current = new AudioContext();
    }
  }, []);

  // TTS mutation
  const { mutate: generateSpeech } = useMutation({
    mutationFn: async (options: Partial<TTSOptions>) => {
      setState(prev => ({ ...prev, isLoading: true, error: null }));
      onStart?.();

      try {
        const ttsOptions: TTSOptions = {
          voice_id: options.voice_id || defaultVoiceId,
          model_id: options.model_id || defaultModelId,
          text: options.text || '',
          voice_settings: options.voice_settings || {
            stability: 0.5,
            similarity_boost: 0.75,
            style: 0.5,
            use_speaker_boost: true,
          },
        };

        const audioData = await client.current!.textToSpeech(ttsOptions);
        
        setState(prev => ({
          ...prev,
          isLoading: false,
          audio: audioData,
        }));

        onComplete?.(audioData);
        return audioData;
      } catch (error) {
        setState(prev => ({
          ...prev,
          isLoading: false,
          error: error as Error,
        }));
        onError?.(error as Error);
        throw error;
      }
    },
  });

  const playAudio = useCallback(async (audioData: ArrayBuffer) => {
    try {
      initAudioContext();
      
      // Stop any playing audio
      if (audioSource.current) {
        audioSource.current.stop();
      }

      const audioBuffer = await audioContext.current!.decodeAudioData(audioData);
      audioSource.current = audioContext.current!.createBufferSource();
      audioSource.current.buffer = audioBuffer;
      audioSource.current.connect(audioContext.current!.destination);

      audioSource.current.onended = () => {
        setState(prev => ({ ...prev, isPlaying: false }));
      };

      setState(prev => ({ ...prev, isPlaying: true }));
      audioSource.current.start();
    } catch (error) {
      setState(prev => ({
        ...prev,
        error: error as Error,
        isPlaying: false,
      }));
      onError?.(error as Error);
    }
  }, [initAudioContext, onError]);

  const stopAudio = useCallback(() => {
    if (audioSource.current) {
      audioSource.current.stop();
      setState(prev => ({ ...prev, isPlaying: false }));
    }
  }, []);

  return {
    ...state,
    generateSpeech,
    playAudio,
    stopAudio,
  };
} 