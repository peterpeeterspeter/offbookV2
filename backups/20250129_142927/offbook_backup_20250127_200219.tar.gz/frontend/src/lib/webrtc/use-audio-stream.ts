import { useEffect, useState, useCallback, useRef } from 'react';
import { useDaily } from './daily-provider';
import { AudioProcessor } from './audio-processor';
import {
  AudioStreamOptions,
  AudioStreamState,
  AudioEffectsConfig,
  DEFAULT_STREAM_OPTIONS,
  AudioProcessorEvent,
} from './audio-types';

export const useAudioStream = (options: AudioStreamOptions = DEFAULT_STREAM_OPTIONS) => {
  const { call, isJoined } = useDaily();
  const [state, setState] = useState<AudioStreamState>({
    isStreaming: false,
    isMuted: false,
    audioContext: null,
    stream: null,
    error: null,
    audioLevel: 0,
    processingEnabled: true,
    effects: options.effects ?? DEFAULT_STREAM_OPTIONS.effects!,
  });

  const processorRef = useRef<AudioProcessor | null>(null);

  // Initialize audio context
  useEffect(() => {
    if (!isJoined) return;

    try {
      const audioContext = new AudioContext({
        sampleRate: options.sampleRate,
        latencyHint: options.latencyHint,
      });
      setState(prev => ({ ...prev, audioContext }));

      return () => {
        audioContext.close();
      };
    } catch (error) {
      setState(prev => ({ ...prev, error: error as Error }));
    }
  }, [isJoined, options.sampleRate, options.latencyHint]);

  // Handle processor events
  useEffect(() => {
    if (!processorRef.current) return;

    const handleProcessorEvent = (event: AudioProcessorEvent) => {
      switch (event.type) {
        case 'error':
          setState(prev => ({ ...prev, error: event.error }));
          break;
        case 'levelUpdate':
          setState(prev => ({ ...prev, audioLevel: event.level }));
          break;
        case 'stateChange':
          setState(prev => ({ ...prev, ...event.state }));
          break;
        case 'disposed':
          setState(prev => ({
            ...prev,
            isStreaming: false,
            stream: null,
            audioLevel: 0,
          }));
          break;
      }
    };

    processorRef.current.on('error', handleProcessorEvent);
    processorRef.current.on('levelUpdate', handleProcessorEvent);
    processorRef.current.on('stateChange', handleProcessorEvent);
    processorRef.current.on('disposed', handleProcessorEvent);

    return () => {
      if (processorRef.current) {
        processorRef.current.removeAllListeners();
      }
    };
  }, []);

  // Start streaming
  const startStreaming = useCallback(async () => {
    if (!call || !state.audioContext) return;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: options.channelCount,
          echoCancellation: options.effects?.echoCancellation ?? true,
          noiseSuppression: true,
          autoGainControl: options.effects?.autoGain ?? true,
        },
      });

      // Create and configure audio processor
      const processor = new AudioProcessor(state.audioContext, state.effects);
      processor.connectSource(stream);
      processorRef.current = processor;

      // Send processed audio to Daily.co
      call.setInputDevices({
        audioSource: processor.getProcessedStream().getAudioTracks()[0],
      });

    } catch (error) {
      setState(prev => ({ ...prev, error: error as Error }));
    }
  }, [call, state.audioContext, state.effects, options]);

  // Stop streaming
  const stopStreaming = useCallback(() => {
    if (processorRef.current) {
      processorRef.current.dispose();
      processorRef.current = null;
    }
  }, []);

  // Toggle audio processing
  const toggleProcessing = useCallback(() => {
    setState(prev => ({ ...prev, processingEnabled: !prev.processingEnabled }));
    if (processorRef.current && state.stream) {
      // Reconnect with/without processing
      call?.setInputDevices({
        audioSource: state.processingEnabled ? 
          state.stream.getAudioTracks()[0] : 
          processorRef.current.getProcessedStream().getAudioTracks()[0],
      });
    }
  }, [call, state.stream, state.processingEnabled]);

  // Update audio effects
  const updateAudioEffects = useCallback((effects: Partial<AudioEffectsConfig>) => {
    if (!processorRef.current) return;

    setState(prev => ({
      ...prev,
      effects: {
        ...prev.effects,
        ...effects,
      },
    }));

    if (effects.eq) {
      processorRef.current.updateEQ(effects.eq);
    }
    if (effects.dynamics) {
      processorRef.current.updateDynamics(effects.dynamics);
    }
    if (effects.noiseGate) {
      processorRef.current.updateNoiseGate(effects.noiseGate);
    }
    if (effects.reverb) {
      processorRef.current.updateReverb(effects.reverb);
    }
    if (effects.delay) {
      processorRef.current.updateDelay(effects.delay);
    }
    if (effects.stereo) {
      processorRef.current.updateStereo(effects.stereo);
    }
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopStreaming();
      if (state.audioContext) {
        state.audioContext.close();
      }
    };
  }, [stopStreaming, state.audioContext]);

  return {
    ...state,
    startStreaming,
    stopStreaming,
    toggleProcessing,
    updateAudioEffects,
  };
}; 