export interface WhisperConfig {
  model: string;
  language?: string;
  task?: 'transcribe' | 'translate';
  temperature?: number;
  prompt?: string;
  response_format?: 'json' | 'text' | 'srt' | 'verbose_json' | 'vtt';
}

export interface WhisperResponse {
  text: string;
  segments?: WhisperSegment[];
  language?: string;
}

export interface WhisperSegment {
  id: number;
  start: number;
  end: number;
  text: string;
  tokens: number[];
  temperature: number;
  avg_logprob: number;
  compression_ratio: number;
  no_speech_prob: number;
}

export interface TranscriptionOptions {
  model?: string;
  language?: string;
  prompt?: string;
  temperature?: number;
  realtime?: boolean;
  onSegment?: (segment: WhisperSegment) => void;
  onError?: (error: Error) => void;
}

export interface TranscriptionState {
  isRecording: boolean;
  isPaused: boolean;
  isProcessing: boolean;
  error: Error | null;
  text: string;
  segments: WhisperSegment[];
  duration: number;
  language?: string;
}

export const DEFAULT_WHISPER_CONFIG: WhisperConfig = {
  model: 'whisper-1',
  task: 'transcribe',
  temperature: 0,
  response_format: 'verbose_json',
}; 