# AI Actor Practice Platform

A real-time AI-powered platform for practicing acting and dialogue delivery, featuring advanced speech analysis, emotion detection, and collaborative practice sessions.

## Features

- **Real-time Speech Analysis**
  - Voice activity detection using Silero VAD
  - Speech-to-text transcription with Whisper
  - Emotion detection and analysis
  - Timing and cadence feedback

- **Text-to-Speech Generation**
  - High-quality voice synthesis with ElevenLabs
  - Emotion-aware speech generation
  - Voice customization and cloning
  - Caching for frequently used lines

- **Script Analysis**
  - Automatic emotion detection in text
  - Character profile analysis
  - Scene breakdown and pacing suggestions
  - Performance metrics tracking

- **Collaborative Features**
  - Multi-user practice sessions
  - Real-time feedback and annotations
  - Role-based scene practice
  - Performance history and progress tracking

## Prerequisites

- Python 3.9 or higher
- CUDA-compatible GPU (recommended for optimal performance)
- FFmpeg for audio processing
- Redis for caching (optional)

## Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/ai-actor-practice.git
cd ai-actor-practice
```

2. Create and activate a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Set up environment variables:
```bash
cp .env.example .env
```
Edit `.env` and add your API keys:
```
ELEVENLABS_API_KEY=your_key_here
DEEPSEEK_API_KEY=your_key_here
DAILY_API_KEY=your_key_here
```

## Usage

1. Start the server:
```bash
uvicorn src.main:app --reload
```

2. Open your browser and navigate to:
```
http://localhost:8000
```

3. Create or join a practice session:
- Upload or select a script
- Choose your character
- Start practicing with AI feedback

## API Documentation

The API documentation is available at:
```
http://localhost:8000/docs
```

## Architecture

### Services

- `CollaborationService`: Manages multi-user sessions and real-time interactions
- `TTSService`: Handles text-to-speech generation using ElevenLabs
- `SpeechRecognitionService`: Processes speech input using Whisper
- `ScriptAnalysisService`: Analyzes scripts and detects emotions
- `VADService`: Provides voice activity detection using Silero VAD
- `TimingService`: Analyzes speech timing and provides feedback

### Data Flow

1. User uploads or selects a script
2. Script is analyzed for emotions and character profiles
3. User begins practice session
4. Real-time audio processing pipeline:
   - Voice activity detection
   - Speech-to-text conversion
   - Emotion and timing analysis
   - Performance feedback generation
5. Results are stored and synchronized across participants

## Development

### Running Tests

```bash
pytest tests/
```

### Code Style

We use:
- Black for code formatting
- isort for import sorting
- flake8 for linting
- mypy for type checking

Run all checks:
```bash
./scripts/lint.sh
```

### Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Run tests and linting
5. Submit a pull request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- [ElevenLabs](https://elevenlabs.io/) for text-to-speech
- [DeepSeek](https://deepseek.com/) for script analysis
- [OpenAI Whisper](https://github.com/openai/whisper) for speech recognition
- [Silero VAD](https://github.com/snakers4/silero-vad) for voice activity detection
- [Daily.co](https://www.daily.co/) for WebRTC infrastructure 