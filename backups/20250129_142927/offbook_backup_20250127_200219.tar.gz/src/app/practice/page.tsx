"use client"

import { CreateSessionDialog } from "@/components/practice/create-session-dialog"

export default function PracticePage() {
  return (
    <main className="container mx-auto py-6">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Practice Sessions</h1>
        <p className="text-muted-foreground mb-8">
          Create a new practice session or join an existing one to start practicing with AI.
        </p>
        <div className="grid gap-6">
          <CreateSessionDialog />
          <div className="border rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-4">Active Sessions</h2>
            <p className="text-muted-foreground">
              No active sessions found. Create a new session to get started.
            </p>
          </div>
        </div>
      </div>
    </main>
  )
} 