"""Add performance indexes

Revision ID: 002
Revises: 001
Create Date: 2024-03-14 11:00:00.000000

"""
from alembic import op

# revision identifiers, used by Alembic.
revision = '002'
down_revision = '001'
branch_labels = None
depends_on = None

def upgrade() -> None:
    # Users table indexes
    op.create_index('idx_users_email', 'users', ['email'])
    op.create_index('idx_users_username', 'users', ['username'])
    op.create_index('idx_users_last_active', 'users', ['last_active'])

    # Scripts table indexes
    op.create_index('idx_scripts_title', 'scripts', ['title'])
    op.create_index('idx_scripts_language', 'scripts', ['language'])
    op.create_index('idx_scripts_created_at', 'scripts', ['created_at'])
    # Create a GIN index for full-text search on title and content
    op.execute(
        'CREATE INDEX idx_scripts_content_gin ON scripts '
        'USING gin(to_tsvector(\'english\', title || \' \' || content))'
    )

    # Characters table indexes
    op.create_index('idx_characters_name', 'characters', ['name'])

    # Scenes table indexes
    op.create_index('idx_scenes_script_number', 'scenes', ['script_id', 'scene_number'])
    op.create_index('idx_scenes_intensity', 'scenes', ['intensity_score'])

    # Practice sessions table indexes
    op.create_index('idx_sessions_active', 'practice_sessions', ['is_active'])
    op.create_index('idx_sessions_script', 'practice_sessions', ['script_id'])
    op.create_index('idx_sessions_date', 'practice_sessions', ['started_at'])

    # Performances table indexes
    op.create_index('idx_performances_user', 'performances', ['user_id'])
    op.create_index('idx_performances_session', 'performances', ['session_id'])
    op.create_index('idx_performances_scene', 'performances', ['scene_id'])
    op.create_index('idx_performances_character', 'performances', ['character_id'])
    op.create_index('idx_performances_time', 'performances', ['start_time'])
    op.create_index('idx_performances_scores', 'performances', [
        'emotion_accuracy',
        'timing_score',
        'pronunciation_score',
        'overall_score'
    ])

    # Recordings table indexes
    op.create_index('idx_recordings_performance', 'recordings', ['performance_id'])
    op.create_index('idx_recordings_created', 'recordings', ['created_at'])

    # Feedback table indexes
    op.create_index('idx_feedback_session', 'feedback', ['session_id'])
    op.create_index('idx_feedback_users', 'feedback', ['from_user_id', 'to_user_id'])
    op.create_index('idx_feedback_created', 'feedback', ['created_at'])

    # TTS Cache table indexes
    op.create_index('idx_tts_cache_lookup', 'tts_cache', ['text', 'voice_id'])
    op.create_index('idx_tts_cache_access', 'tts_cache', ['last_accessed'])
    op.create_index('idx_tts_cache_count', 'tts_cache', ['access_count'])

def downgrade() -> None:
    # Drop all indexes in reverse order
    op.drop_index('idx_tts_cache_count', 'tts_cache')
    op.drop_index('idx_tts_cache_access', 'tts_cache')
    op.drop_index('idx_tts_cache_lookup', 'tts_cache')

    op.drop_index('idx_feedback_created', 'feedback')
    op.drop_index('idx_feedback_users', 'feedback')
    op.drop_index('idx_feedback_session', 'feedback')

    op.drop_index('idx_recordings_created', 'recordings')
    op.drop_index('idx_recordings_performance', 'recordings')

    op.drop_index('idx_performances_scores', 'performances')
    op.drop_index('idx_performances_time', 'performances')
    op.drop_index('idx_performances_character', 'performances')
    op.drop_index('idx_performances_scene', 'performances')
    op.drop_index('idx_performances_session', 'performances')
    op.drop_index('idx_performances_user', 'performances')

    op.drop_index('idx_sessions_date', 'practice_sessions')
    op.drop_index('idx_sessions_script', 'practice_sessions')
    op.drop_index('idx_sessions_active', 'practice_sessions')

    op.drop_index('idx_scenes_intensity', 'scenes')
    op.drop_index('idx_scenes_script_number', 'scenes')

    op.drop_index('idx_characters_name', 'characters')

    op.execute('DROP INDEX idx_scripts_content_gin')
    op.drop_index('idx_scripts_created_at', 'scripts')
    op.drop_index('idx_scripts_language', 'scripts')
    op.drop_index('idx_scripts_title', 'scripts')

    op.drop_index('idx_users_last_active', 'users')
    op.drop_index('idx_users_username', 'users')
    op.drop_index('idx_users_email', 'users') 